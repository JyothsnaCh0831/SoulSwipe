//
//  Model.swift
//  SoulSwipeProject
//
//  Created by Jyothsna on 10/18/23.
//

import Foundation
import UIKit
import FirebaseAuth
import FirebaseFirestore

struct UtilityConstants {
    
    /* Compatibility Questions */
    static let compatibilityQuestions = [
        CompatibilityQuestion(question: "What values are more important to you?", options: ["Love", "True Friendship", "A successful career", "A comfortable home with the person I love", "Peace and Happiness"], numberOfOptions: 2),
        CompatibilityQuestion(question: "What kind of vacation do you like to take?", options: ["Beach", "Camping", "Group Travel", "Adventure", "Cruise"], numberOfOptions: 2),
        CompatibilityQuestion(question: "What kind of hobbies do you have?", options: ["Sports", "Films / Reels", "Cooking", "Music / Dancing", "Movie", "Reading Books"], numberOfOptions: 2),
        CompatibilityQuestion(question: "What do you think is most important in relationship?", options: ["Accepting our imperfections", "Giving each other a lot of space", "Understanding and supoorting each other", "Considering each other in what you want"], numberOfOptions: 1),
        CompatibilityQuestion(question: "What do you think about marriage?", options: ["If two people really like each other, they should get married", "Anyone wanting to start a family should get married", "Marriage is completely neccessary"], numberOfOptions: 1),
        CompatibilityQuestion(question: "Are you a morning person or a night person?", options: ["Morning person", "Night person", "It depends on the day"], numberOfOptions: 1),
        CompatibilityQuestion(question: "How do you keep romance alive in a long-term relationship?", options: ["Suprises: Plan unexpected dates or small gifts for your partner", "Communication: Express love and appreciation regularly", "Shared experiences: Create new memories and explore new activities together", "Intimacy: Maintain a healthy and fulfilling sexual connection"], numberOfOptions: 1),
        CompatibilityQuestion(question: "How do you support each other's personal growth within a relationship?", options: ["Encouragement: Cheer on your partner's ambitions and help them achieve their goals.", "Active involvement: Provide assistance, feedback, and resources whenever possible.", "Acceptance: Embrace each other's changes and growth, even if it means evolving individually.", "Celebrate milestones: Recognize and celebrate achievements together."], numberOfOptions: 1)
    ]
    static let twoOptionsMessage = "Choose atmost 2 options"
    static let oneOptionsMessage = "Choose only 1 option"
    
    
    /* Profile Screen Options */
    static let profileScreenOptions: [ProfileScreenOptions] = [
        ProfileScreenOptions(option: "Likes", image: "heart.fill"),
        ProfileScreenOptions(option: "Edit Questionnaire", image: "pencil"),
        ProfileScreenOptions(option: "Messages", image: "message.fill"),
        ProfileScreenOptions(option: "Announcements", image: "speaker.wave.2.bubble.left.fill"),
        ProfileScreenOptions(option: "Change Password", image: "lock.fill"),
        ProfileScreenOptions(option: "Delete Account", image: "person.crop.circle.badge.xmark"),
        ProfileScreenOptions(option: "Logout", image: "rectangle.portrait.and.arrow.right.fill")
    ]
    
    /* Alerts */
    static let defaultAction = UIAlertAction(title: "OK", style: .default)
    
    static func displayAlert(for view: UIViewController, having title: String, with message: String, and action: UIAlertAction) {
        let alertController = UIAlertController(title: title, message: message, preferredStyle: .alert)
        alertController.addAction(action)
        view.present(alertController, animated: true, completion: nil)
    }
    
    /* Firestore Database variable */
    static let db = Firestore.firestore()
    
    /* To handle compatability scores */
    static var currentUserQuizAnswers: [String: [String]] = [:]
    static var otherUsersQuizAnswers: [String: [[String: [String]]]] = [:]
    
    /* To display alert for logout */
    static func alertForLogout(for view: UIViewController) {
        do {
            let alert = UIAlertController(title: "Logout", message: "Are you sure you want to log out?", preferredStyle: .alert)
            
            let cancelAction = UIAlertAction(title: "Cancel", style: .cancel, handler: nil)
            alert.addAction(cancelAction)
            
            let logoutAction = UIAlertAction(title: "Logout", style: .destructive) { _ in
                UtilityConstants.performLogout(for: view)
            }
            alert.addAction(logoutAction)
            view.present(alert, animated: true, completion: nil)
        }
    }
    
    /* Handle to logout */
    static func performLogout(for view: UIViewController) {
        do {
            try Auth.auth().signOut()
            
            /* Setting User defaults to false */
            UserDefaults.standard.set(false, forKey: "isLoggedIn")
            
            /* Navigate to login screen */
            let login = view.storyboard?.instantiateViewController(withIdentifier: "loginScreen")as! LoginScreen
            view.navigationController?.pushViewController(login, animated: true)
            
            // If successful, update UI or perform other actions
            print("User logged out successfully")
        } catch let signOutError as NSError {
            print("Error signing out: \(signOutError)")
        }
    }
}

struct ProfileScreenOptions {
    var option: String
    var image: String
}

struct CompatibilityQuestion {
    var question: String
    var options: [String]
    var numberOfOptions: Int
}

struct Settings {
    var option: String
    var icon: String
}
