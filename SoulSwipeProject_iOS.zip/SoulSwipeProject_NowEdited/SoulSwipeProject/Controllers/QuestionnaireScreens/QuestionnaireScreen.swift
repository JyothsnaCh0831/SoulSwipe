//
//  QuestionnaireScreen.swift
//  SoulSwipeProject
//
//  Created by Jyothsna on 10/18/23.
//

import UIKit

class QuestionnaireScreen: UIViewController {

    override func viewDidLoad() {
        super.viewDidLoad()
        
        /* Customize the back button text for this view controller */
        let backButton = UIBarButtonItem()
        backButton.tintColor = UIColor.systemRed
        self.navigationController?.navigationBar.topItem?.backBarButtonItem = backButton

    }
    
    
    @IBAction func onClickTakeQuiz(_ sender: UIButton) {
        /* Navigating to Quiz Screen */
        self.performSegue(withIdentifier: "showQuizQuestionScreen", sender: self)
    }

}
