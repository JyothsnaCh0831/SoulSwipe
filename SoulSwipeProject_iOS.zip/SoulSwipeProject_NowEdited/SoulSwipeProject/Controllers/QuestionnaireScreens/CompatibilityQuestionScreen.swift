//
//  CompatibilityQuestionScreen.swift
//  SoulSwipeProject
//
//  Created by Jyothsna on 10/18/23.
//

import UIKit
import FirebaseAuth
import FirebaseFirestore

class CompatibilityQuestionScreen: UIViewController {
    
    var questionNumber: Int = 0
    var selectedQuestionOptions: [Int : [String]] = [0: [], 1: [], 2: [], 3: [], 4: [], 5: [], 6: [], 7: []]
    
    @IBOutlet weak var questionLBL: UILabel!
    
    @IBOutlet weak var optionsMessageLBL: UILabel!
    
    @IBOutlet weak var optionsSV: UIStackView!
    
    override func viewDidLoad() {
        super.viewDidLoad()

        /* Customize the back button text for this view controller */
        let backButton = UIBarButtonItem()
        backButton.tintColor = UIColor.systemRed
        self.navigationController?.navigationBar.topItem?.backBarButtonItem = backButton
        
        /* Display each question and the buttons based on the number of options */
        self.displayQuestionAndOptions(for: self.questionNumber)
    }
    
    @IBAction func onClickNext(_ sender: UIButton) {
        
        /* If user hasn't select any options */
        if(self.selectedQuestionOptions[self.questionNumber]!.count == 0) {
            UtilityConstants.displayAlert(for: self, having: "Info", with: "You can't skip a question without answering", and: UtilityConstants.defaultAction)
        } 
        /* If chooses less than required option */
        else if (self.selectedQuestionOptions[self.questionNumber]!.count != UtilityConstants.compatibilityQuestions[self.questionNumber].numberOfOptions) {
            UtilityConstants.displayAlert(for: self, having: "Info", with: "You must choose atmost options as provided.", and: UtilityConstants.defaultAction)
            
        } 
        else {
            /* Increment the question number */
            self.questionNumber += 1
            
            if (self.questionNumber <= 7) {
                /* Display the buttons based on the number of options */
                self.displayQuestionAndOptions(for: self.questionNumber)
                
            } else {
                print("Else condition")
                /* Store the quiz answers in Firestore  */
                self.storeAnswersToDB()
                
                let action = UIAlertAction(title: "OK", style: .default) { _ in
                    /* Navigating to Tab Bar Screen */
                    let tabbar = self.storyboard?.instantiateViewController(withIdentifier: "userTabBar") as! UserTabBar
                    self.navigationController?.pushViewController(tabbar, animated: true)
                }
                
                UtilityConstants.displayAlert(for: self, having: "Success", with: "Thank you for taking our questionnaire. We gonna calculate your compatibility score with other partner seekers.", and: action)
                
            }
        }
        
    }

    
    /* Display buttons in the screen */
    private func displayQuestionAndOptions(for question: Int) {
        
        /* Setting the question and options */
        self.questionLBL.text = UtilityConstants.compatibilityQuestions[question].question
        
        if(UtilityConstants.compatibilityQuestions[question].numberOfOptions == 2) {
            self.optionsMessageLBL.text = UtilityConstants.twoOptionsMessage
        } else {
            self.optionsMessageLBL.text = UtilityConstants.oneOptionsMessage
        }
        
        /* Remove the options of previous question */
        for subview in self.optionsSV.subviews {
            subview.removeFromSuperview()
        }
        
        /* Add options of current question */
        for (index, element) in UtilityConstants.compatibilityQuestions[question].options.enumerated() {
            let btn: UIButton = {
                let button = UIButton()
                button.setTitle(element, for: .normal)
                button.backgroundColor = UIColor.systemGray6
                button.setTitleColor(UIColor.systemBlue, for: .normal)
                button.titleLabel?.lineBreakMode = .byWordWrapping
                button.contentVerticalAlignment = .center
                button.contentHorizontalAlignment = .center
                button.layer.cornerRadius = 10.0
                button.addTarget(self, action: #selector(self.selectOption(_:)), for: .touchUpInside)
                button.tag = index
                
                return button
            }()
            self.optionsSV.addArrangedSubview(btn)
        }
    }
    
    /* When any option is tapped */
    @IBAction func selectOption(_ sender: UIButton) {
        let numberOfOptions = UtilityConstants.compatibilityQuestions[self.questionNumber].numberOfOptions
        
        /* If option is not chosen */
        if(!self.selectedQuestionOptions[self.questionNumber]!.contains((sender.titleLabel?.text)!) && self.selectedQuestionOptions[self.questionNumber]!.count < UtilityConstants.compatibilityQuestions[self.questionNumber].numberOfOptions) {
            sender.backgroundColor = UIColor(red: 177.0/255.0, green: 125.0/255.0, blue: 255.0/255.0, alpha: 0.7)
            sender.setTitleColor(UIColor.white, for: .normal)
            self.selectedQuestionOptions[self.questionNumber]!.append((sender.titleLabel?.text)!)
        } 
        
        /* If option is already chosen */
        else if(self.selectedQuestionOptions[self.questionNumber]!.contains((sender.titleLabel?.text)!)){
            self.selectedQuestionOptions[self.questionNumber]!.remove(at: self.selectedQuestionOptions[self.questionNumber]!.lastIndex(of: (sender.titleLabel?.text)!)!)
            sender.backgroundColor = UIColor.systemGray6
            sender.setTitleColor(UIColor.systemBlue, for: .normal)
        } 
        else {
            UtilityConstants.displayAlert(for: self, having: "Info", with: "You can't select more than \(numberOfOptions) options", and: UtilityConstants.defaultAction)
        }
    }
    
    /* Store the quiz answers to DB */
    private func storeAnswersToDB() {
        
        /* Get the email of the user */
        guard let user = Auth.auth().currentUser, let email = user.email else {
            print("User mail is empty")
            return
        }
        
        /* Update to DB */
        UtilityConstants.db.collection("CompatibilityQuiz").document(email).setData(
            [
                "questionOne": self.selectedQuestionOptions[0]!,
                "questionTwo": self.selectedQuestionOptions[1]!,
                "questionThree": self.selectedQuestionOptions[2]!,
                "questionFour": self.selectedQuestionOptions[3]!,
                "questionFive": self.selectedQuestionOptions[4]!,
                "questionSix": self.selectedQuestionOptions[5]!,
                "questionSeven": self.selectedQuestionOptions[6]!,
                "questionEight": self.selectedQuestionOptions[7]!
            ]
        )
    }
    
}
