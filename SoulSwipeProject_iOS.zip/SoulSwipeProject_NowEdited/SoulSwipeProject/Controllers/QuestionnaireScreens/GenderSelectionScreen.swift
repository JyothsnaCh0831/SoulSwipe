//
//  GenderSelectionScreen.swift
//  SoulSwipeProject
//
//  Created by Jyothsna on 10/17/23.
//

import UIKit
import FirebaseAuth
import FirebaseFirestore

class GenderSelectionScreen: UIViewController {
    
    var gender: String = ""
    var partnerGender: String = ""
    
    @IBOutlet weak var userGenderSC: UISegmentedControl!
    
    @IBOutlet weak var partnerGenderSC: UISegmentedControl!
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        /* Customize the back button text for this view controller */
        let backButton = UIBarButtonItem()
        backButton.tintColor = UIColor.systemRed
        self.navigationController?.navigationBar.topItem?.backBarButtonItem = backButton
        
        /* Initially no selection for segues */
        self.partnerGenderSC.selectedSegmentIndex = -1
        self.userGenderSC.selectedSegmentIndex = -1
    }
    
    
    @IBAction func onSelectingGender(_ sender: UISegmentedControl) {
        switch sender.selectedSegmentIndex {
        case 0:
            self.gender = "Male"
        case 1:
            self.gender = "Female"
        default:
            self.gender = ""
        }
    }
    
    @IBAction func onSelectingPartnerGender(_ sender: UISegmentedControl) {
        switch sender.selectedSegmentIndex {
        case 0:
            self.partnerGender = "Male"
        case 1:
            self.partnerGender = "Female"
        default:
            self.partnerGender = ""
        }
    }
    
    
    @IBAction func onClickContinue(_ sender: UIButton) {
        
        /* Store the gender details in the Firestore */
        UtilityConstants.db.collection("Users").document((Auth.auth().currentUser?.email)!).updateData(
            [
                "gender": self.gender,
                "partnerGender": self.partnerGender
            ]
        )
        { err in
            if let e = err {
                print(e.localizedDescription)
            } else {
                let action = UIAlertAction(title: "OK", style: .default) { (action) in
                    /* Navigating to Questionnaire Screen */
                    self.performSegue(withIdentifier: "showQuestionnaireScreen", sender: self)
                }
                UtilityConstants.displayAlert(for: self, having: "Success", with: "Thank you for your information. Please answer the questionnaire in the coming section.", and: action)
            }
        }
    }
}
