//
//  UserTabBar.swift
//  SoulSwipeProject
//
//  Created by Jyothsna on 10/18/23.
//

/*import UIKit
 
 class UserTabBar: UITabBarController {
 
 override func viewDidLoad() {
 super.viewDidLoad()
 
 /* Customize the back button text for this view controller */
 self.navigationItem.hidesBackButton = true
 }
 
 }*/

import UIKit
import CometChatUIKitSwift
import CometChatSDK

class UserTabBar: UITabBarController {
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        /* Customize the back button text for this view controller */
        self.navigationItem.hidesBackButton = true
        
        // Create instances of your view controllers
        let storyboard = UIStoryboard(name: "Main", bundle: nil)
        let homeTab = storyboard.instantiateViewController(withIdentifier: "HomeVC") as! HomeVC
        let favoritesTab = storyboard.instantiateViewController(withIdentifier: "FavoritesScreen") as! FavoritesScreen
        let profileTab = storyboard.instantiateViewController(withIdentifier: "ProfileScreen") as! ProfileScreen
    
        // Instantiate the CometChatTab class
        let cometChatTab = CometChatTab()
        cometChatTab.tabBarItem = UITabBarItem(title: "Chats", image: UIImage(systemName: "ellipsis.message.fill"), selectedImage: UIImage(systemName: "ellipsis.message"))
        tabBar.tintColor = UIColor.systemRed
        
        // Add view controllers to the tab bar
        self.viewControllers = [homeTab, favoritesTab, cometChatTab, profileTab]
    }
}
