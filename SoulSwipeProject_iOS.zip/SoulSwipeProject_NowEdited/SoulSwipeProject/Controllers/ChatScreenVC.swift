//
//  ChatScreenVC.swift
//  SoulSwipeProject
//
//  Created by Devineni Vasavi on 11/7/23.
//

import UIKit
import CometChatSDK
import CometChatUIKitSwift
import Firebase

class ChatScreenVC: UIViewController {
    
    @IBOutlet var container: UIView!
    
    override func viewDidLoad() {
        super.viewDidLoad()
    }
    
    override func viewWillAppear(_ animated: Bool) {
        super.viewWillAppear(animated)
        
        self.getUserDetails() { (uid,name)  in
            let user = User(uid: uid, name: name)
            
            let cometChatConversationsWithMessages = CometChatConversationsWithMessages()
            cometChatConversationsWithMessages.navigationItem.setHidesBackButton(true, animated: false)
            self.navigationController?.navigationBar.tintColor = .red
            cometChatConversationsWithMessages.hide(separator: true)
            self.navigationController?.pushViewController(cometChatConversationsWithMessages, animated: true)
            
            let listItemStyle = ListItemStyle()
            listItemStyle.set(cornerRadius: CometChatCornerStyle(cornerRadius: 12.0))
                .set(background: .white)
                .set(borderColor: .black)
            cometChatConversationsWithMessages.set(listItemStyle: listItemStyle)
            
            //CometChatCallButtons()
            let cometChatCallButton = CometChatCallButtons(width: 70, height: 70)
            cometChatCallButton.set(user: user)
            self.container.addSubview(cometChatCallButton)
        }
    }
    
    private func getUserDetails(completion: @escaping (String, String) -> Void){
        /* Current user email */
        guard let user = Auth.auth().currentUser, let email = user.email else {
            return
        }
        
        UtilityConstants.db.collection("Users").document(email).getDocument { (document, error) in
            if let error = error {
                print("Error getting document: \(error)")
            } else if let document = document, document.exists {
                if let data = document.data(){
                    let cometChatID = data["cometchatID"] as! String
                    let fullName = data["fullName"] as! String
                    completion(cometChatID, fullName)
                }
            } else {
                print("Document does not exist")
            }
        }
    }
}
