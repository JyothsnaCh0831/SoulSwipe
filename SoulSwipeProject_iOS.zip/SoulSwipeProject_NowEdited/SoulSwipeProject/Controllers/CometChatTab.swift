//
//  CometChatTab.swift
//  SoulSwipeProject
//
//  Created by Devineni Vasavi on 11/13/23.
//

import UIKit
import Firebase
import CometChatUIKitSwift
import CometChatSDK

class CometChatTab: UITabBarController {
    
    private let conversations = UINavigationController()
    private let cometChatConversationsWithMessages = CometChatConversationsWithMessages()
    private let cometChatListBase = CometChatListBase()
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        // Setting the title for the navigation controller
        self.conversations.navigationBar.prefersLargeTitles = true
        self.conversations.viewControllers = [self.cometChatConversationsWithMessages]
        
        // Configure cometChatConversationsWithMessages
        self.cometChatConversationsWithMessages.hide(separator: true)
        
        // Configure list item style
        let listItemStyle = ListItemStyle()
        listItemStyle.set(cornerRadius: CometChatCornerStyle(cornerRadius: 12.0))
            .set(background: .white)
            .set(borderColor: .black)
        self.cometChatConversationsWithMessages.set(listItemStyle: listItemStyle)
        
        self.viewControllers = [self.conversations]
        
        /*self.getUserDetails() { (uid, name) in
            _ = User(uid: uid, name: name)
        }*/
    }
    
    override func viewWillAppear(_ animated: Bool) {
        super.viewWillAppear(animated)
        
        // Access the right bar button item and modify its appearance
        if let rightBarButtonItem = self.conversations.topViewController?.navigationItem.rightBarButtonItem {
            rightBarButtonItem.tintColor = .red
        }
    }
    
    /*private func getUserDetails(completion: @escaping (String, String) -> Void){
        /* Current user email */
        guard let user = Auth.auth().currentUser, let email = user.email else {
            return
        }
        
        UtilityConstants.db.collection("Users").document(email).getDocument { (document, error) in
            if let error = error {
                print("Error getting document: \(error)")
            } else if let document = document, document.exists {
                if let data = document.data(){
                    let cometChatID = data["cometchatID"] as! String
                    let fullName = data["fullName"] as! String
                    completion(cometChatID, fullName)
                }
            } else {
                print("Document does not exist")
            }
        }
    }*/
    
}
