//
//  EditQuestionnaireCell.swift
//  SoulSwipeProject
//
//  Created by Jyothsna on 10/22/23.
//

import UIKit

class EditQuestionnaireCell: UITableViewCell {
    
    @IBOutlet weak var questionLBL: UILabel!
    
    override func awakeFromNib() {
        super.awakeFromNib()
        // Initialization code
    }

    override func setSelected(_ selected: Bool, animated: Bool) {
        super.setSelected(selected, animated: animated)

        // Configure the view for the selected state
    }

}
