//
//  UpdateQuestionnaireVC.swift
//  SoulSwipeProject
//
//  Created by Jyothsna on 10/22/23.
//

import UIKit
import FirebaseAuth
import FirebaseFirestore

class UpdateQuestionnaireVC: UIViewController {
    
    var selectedQuestionIndex: Int = 0
    var updatedQuestionOptions: [String] = []
    
    /* Stored in DB */
    var selectedQuestionOptions: [String] = []
    
    @IBOutlet weak var questionLBL: UILabel!
    
    @IBOutlet weak var chooseOptionsLBL: UILabel!
    
    @IBOutlet weak var optionsSV: UIStackView!
    

    override func viewDidLoad() {
        super.viewDidLoad()
        
        /* Customize the back button text for this view controller */
        let backButton = UIBarButtonItem()
        backButton.tintColor = UIColor.systemRed
        self.navigationController?.navigationBar.topItem?.backBarButtonItem = backButton
        
        
        /* Get answers from the db */
        self.getAnswersFromDB()

        /* Display the question and options */
        self.questionLBL.text = UtilityConstants.compatibilityQuestions[self.selectedQuestionIndex].question
        self.chooseOptionsLBL.text = (UtilityConstants.compatibilityQuestions[self.selectedQuestionIndex].numberOfOptions == 1) ? UtilityConstants.oneOptionsMessage : UtilityConstants.twoOptionsMessage
    }
    
    
    @IBAction func onClickUpdate(_ sender: UIButton) {
        /* If user hasn't select any options */
        if(self.updatedQuestionOptions.count == 0) {
            UtilityConstants.displayAlert(for: self, having: "Info", with: "You can't skip a question without answering", and: UtilityConstants.defaultAction)
        }
        /* If chooses less than required option */
        else if (self.updatedQuestionOptions.count != UtilityConstants.compatibilityQuestions[self.selectedQuestionIndex].numberOfOptions) {
            UtilityConstants.displayAlert(for: self, having: "Info", with: "You must choose atmost options as provided.", and: UtilityConstants.defaultAction)
            
        }
        else {
            /* Update answers to database */
            self.updatedQuestionOptionsToDB()
            
            UtilityConstants.displayAlert(for: self, having: "Success", with: "Your answers are updated into the database.", and: UtilityConstants.defaultAction)
        }
    }
}

extension UpdateQuestionnaireVC {
    
    /* Getting chosen answers from DB */
    private func getAnswersFromDB() {
        let quizAnswersRef = UtilityConstants.db.collection("CompatibilityQuiz").document((Auth.auth().currentUser?.email)!)
        
        quizAnswersRef.getDocument {
            (document, error) in
            if let document = document, document.exists {
                let details = document.data()!
                
                self.selectedQuestionOptions.append(contentsOf: details[self.getQuestion(using: self.selectedQuestionIndex)] as! [String])
                
            }
            self.displayQuestionAndOptions()
        }
    }
    
    /* Getting the question using index */
    private func getQuestion(using index: Int) -> String {
        switch index {
        case 0:
            return "questionOne"
        case 1:
            return "questionTwo"
        case 2:
            return "questionThree"
        case 3:
            return "questionFour"
        case 4:
            return "questionFive"
        case 5:
            return "questionSix"
        case 6:
            return "questionSeven"
        case 7:
            return "questionEight"
        default:
            return ""
        }
    }
    
    
    /* Display buttons in the screen */
    private func displayQuestionAndOptions() {
        
        /* Remove the options of previous question */
        for subview in self.optionsSV.subviews {
            subview.removeFromSuperview()
        }
        
        /* Add options of current question */
        for (index, element) in UtilityConstants.compatibilityQuestions[self.selectedQuestionIndex].options.enumerated() {
            let btn: UIButton = {
                let button = UIButton()
                button.setTitle(element, for: .normal)
                
                /* Styling the buttons */
                if(self.selectedQuestionOptions.contains(element) == true) {
                    button.backgroundColor = UIColor(red: 177.0/255.0, green: 125.0/255.0, blue: 255.0/255.0, alpha: 0.7)
                    button.setTitleColor(UIColor.white, for: .normal)
                } else {
                    button.backgroundColor = UIColor.systemGray6
                    button.setTitleColor(UIColor.systemBlue, for: .normal)
                }
            
                button.titleLabel?.lineBreakMode = .byWordWrapping
                button.contentVerticalAlignment = .center
                button.contentHorizontalAlignment = .center
                button.layer.cornerRadius = 10.0
                button.addTarget(self, action: #selector(self.selectOption(_:)), for: .touchUpInside)
                button.tag = index
                
                return button
            }()
            self.optionsSV.addArrangedSubview(btn)
        }
    }
    
    /* When any option is tapped */
    @IBAction func selectOption(_ sender: UIButton) {
        let numberOfOptions = UtilityConstants.compatibilityQuestions[self.selectedQuestionIndex].numberOfOptions
        
        /* If option is not chosen */
        if(!self.updatedQuestionOptions.contains((sender.titleLabel?.text)!) && self.updatedQuestionOptions.count < UtilityConstants.compatibilityQuestions[self.selectedQuestionIndex].numberOfOptions) {
            sender.backgroundColor = UIColor(red: 177.0/255.0, green: 125.0/255.0, blue: 255.0/255.0, alpha: 0.7)
            sender.setTitleColor(UIColor.white, for: .normal)
            self.updatedQuestionOptions.append((sender.titleLabel?.text)!)
        }
        
        /* If option is already chosen */
        else if(self.updatedQuestionOptions.contains((sender.titleLabel?.text)!)){
            self.updatedQuestionOptions.remove(at: self.updatedQuestionOptions.lastIndex(of: (sender.titleLabel?.text)!)!)
            sender.backgroundColor = UIColor.systemGray6
            sender.setTitleColor(UIColor.systemBlue, for: .normal)
        }
        else {
            UtilityConstants.displayAlert(for: self, having: "Info", with: "You can't select more than \(numberOfOptions) options", and: UtilityConstants.defaultAction)
        }
    }
    
    /* Update the answers in to DB */
    private func updatedQuestionOptionsToDB() {
        
        UtilityConstants.db.collection("CompatibilityQuiz").document((Auth.auth().currentUser?.email)!).updateData([
            self.getQuestion(using: self.selectedQuestionIndex): self.updatedQuestionOptions
        ]) { err in
            if let e = err {
                print(e.localizedDescription)
            }
        }
    }
}
