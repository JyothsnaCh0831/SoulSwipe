//
//  EditQuestionnaireVC.swift
//  SoulSwipeProject
//
//  Created by Jyothsna on 10/22/23.
//

import UIKit

class EditQuestionnaireVC: UIViewController, UITableViewDelegate, UITableViewDataSource {
    
    @IBOutlet weak var editQuestionsTV: UITableView!
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        /* Display the nav bar */
        self.navigationController?.navigationBar.isHidden = false
        
        /* Customize the back button text for this view controller */
        let backButton = UIBarButtonItem()
        backButton.tintColor = UIColor.systemRed
        self.navigationController?.navigationBar.topItem?.backBarButtonItem = backButton
        
        /* Answering the table view delegate */
        self.editQuestionsTV.dataSource = self
        self.editQuestionsTV.delegate = self
        
        /* Styling the table view */
        self.editQuestionsTV.separatorStyle = .none
        self.editQuestionsTV.separatorInset = UIEdgeInsets(top: 10, left: 16, bottom: 10, right: 16)
        
    }
    
    func numberOfSections(in tableView: UITableView) -> Int {
        return UtilityConstants.compatibilityQuestions.count
    }
    
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return 1
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let cell = self.editQuestionsTV.dequeueReusableCell(withIdentifier: "question", for: indexPath) as! EditQuestionnaireCell
        
        /* Apply the corner radius and mask to bounds to round the cell */
        cell.layer.cornerRadius = 12.0
        cell.layer.masksToBounds = true
        
        /* Set the background color of the cell */
        cell.contentView.backgroundColor = UIColor.white
        
        /* Spacing between the cells */
        cell.frame = cell.frame.inset(by: UIEdgeInsets(top: 60, left: 60, bottom: 60, right: 60))
        
        cell.questionLBL.text = UtilityConstants.compatibilityQuestions[indexPath.section].question
        return cell
    }
    
    func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath) {
        self.editQuestionsTV.deselectRow(at: indexPath, animated: true)
        
        /* Navigating to Update Questionnaire Screen */
        let update = self.storyboard?.instantiateViewController(withIdentifier: "updateQuestionnaireScreen")as! UpdateQuestionnaireVC
        update.selectedQuestionIndex = indexPath.section
        self.navigationController?.pushViewController(update, animated: true)
    }
    
    func tableView(_ tableView: UITableView, heightForRowAt indexPath: IndexPath) -> CGFloat {
        return 65
    }
    
    /* Spacing between the cells */
    func tableView(_ tableView: UITableView, heightForHeaderInSection section: Int) -> CGFloat {
        return 1.0
    }
    
    func tableView(_ tableView: UITableView, viewForHeaderInSection section: Int) -> UIView? {
        let headerView = UIView()
        headerView.backgroundColor = UIColor.clear
        return headerView
    }
    
}
