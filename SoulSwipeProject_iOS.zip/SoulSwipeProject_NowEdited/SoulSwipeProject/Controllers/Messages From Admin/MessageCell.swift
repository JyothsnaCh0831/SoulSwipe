//
//  MessageCell.swift
//  SoulSwipeProject
//
//  Created by Jyothsna on 10/24/23.
//

import UIKit

class MessageCell: UITableViewCell {
    
    @IBOutlet weak var titleLBL: UILabel!
    
    @IBOutlet weak var dateLBL: UILabel!
    
    @IBOutlet weak var messageLBL: UILabel!
    
    override func awakeFromNib() {
        super.awakeFromNib()
        // Initialization code
    }

    override func setSelected(_ selected: Bool, animated: Bool) {
        super.setSelected(selected, animated: animated)

        // Configure the view for the selected state
    }

}
