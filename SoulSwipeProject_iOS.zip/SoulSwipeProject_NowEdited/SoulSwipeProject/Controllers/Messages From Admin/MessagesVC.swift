//
//  MessagesVC.swift
//  SoulSwipeProject
//
//  Created by Jyothsna on 10/24/23.
//

import UIKit
import FirebaseAuth

class MessagesVC: UIViewController, UITableViewDelegate, UITableViewDataSource {
    
    /* Storing all messages */
    var messages: [[String: Any]] = []
    
    /* For Expanding the cell */
    var isCellExpanded: Bool = false
    var selectedRowIndex: Int?
    
    @IBOutlet weak var messagesTV: UITableView!

    override func viewDidLoad() {
        super.viewDidLoad()
        
        /* Display the nav bar */
        self.navigationController?.navigationBar.isHidden = false

        /* Customize the back button text for this view controller */
        let backButton = UIBarButtonItem()
        backButton.tintColor = UIColor.systemRed
        self.navigationController?.navigationBar.topItem?.backBarButtonItem = backButton
        
        /* Answering the delegate */
        self.messagesTV.dataSource = self
        self.messagesTV.delegate = self
        
        /* Styling the table view */
        self.messagesTV.separatorStyle = .none
        
        /* Calling method to read announcements */
        self.readMessagesFromDB { messagesData in
            self.messages = messagesData
            self.messagesTV.reloadData()
        }
    }
    
    /* Overriding the table view methods */
    func numberOfSections(in tableView: UITableView) -> Int {
        return self.messages.count
    }
    
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return 1
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let cell = self.messagesTV.dequeueReusableCell(withIdentifier: "messageCell", for: indexPath) as! MessageCell
        
        /* Apply the corner radius and mask to bounds to round the cell */
        cell.layer.cornerRadius = 12.0
        cell.layer.masksToBounds = true

        /* Set the background color of the cell */
        cell.contentView.backgroundColor = UIColor.white

        let data = self.messages[indexPath.section]
        
        cell.titleLBL.text = data["title"] as? String
        cell.dateLBL.text = data["date"] as? String
        cell.messageLBL.text = isCellExpanded && indexPath.row == selectedRowIndex ? data["message"] as? String: ""
        
        return cell
    }
    
    func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath) {
        self.messagesTV.deselectRow(at: indexPath, animated: true)
        
        if selectedRowIndex == indexPath.row {
            isCellExpanded = !isCellExpanded
            selectedRowIndex = nil
        } else {
            isCellExpanded = true
            selectedRowIndex = indexPath.row
        }
        
        self.messagesTV.reloadData()
    }
    
    func tableView(_ tableView: UITableView, heightForRowAt indexPath: IndexPath) -> CGFloat {
        return indexPath.row == selectedRowIndex ? 100 : 60
    }
    
    
    /* Spacing between the cells */
    func tableView(_ tableView: UITableView, heightForHeaderInSection section: Int) -> CGFloat {
        return 1.0
    }
    
    func tableView(_ tableView: UITableView, viewForHeaderInSection section: Int) -> UIView? {
        let headerView = UIView()
        headerView.backgroundColor = UIColor.clear
        return headerView
    }
}

extension MessagesVC {
    /* Read all messages from DB */
    func readMessagesFromDB(completion: @escaping ([[String: Any]]) -> Void) {
        
        /* Current user email */
        guard let user = Auth.auth().currentUser, let email = user.email else {
            return
        }
        
        let messagesRef = UtilityConstants.db.collection("Notifications")
        
        messagesRef.getDocuments { (querySnapshot, error) in
            if let e = error {
                print(e.localizedDescription)
                return
            }
            
            var data: [[String: Any]] = []
            
            for document in querySnapshot!.documents {
                let messages = document.data()
                if let messagesDetails = messages["notifications"] as? [[String: Any]] {
                    for details in messagesDetails {
                        if let users = details["users"] as? [[String: Any]] {
                            for user in users {
                                if(user["email"] as! String == email) {
                                    data.append(details)
                                }
                            }
                        }
                    }
                }
            }
            completion(data)
        }
    }
}
