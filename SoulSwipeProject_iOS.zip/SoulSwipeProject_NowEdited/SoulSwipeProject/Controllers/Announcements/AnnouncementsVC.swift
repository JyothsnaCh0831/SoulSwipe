//
//  AnnouncementsVC.swift
//  SoulSwipeProject
//
//  Created by Jyothsna on 11/5/23.
//

import UIKit

class AnnouncementsVC: UIViewController, UITableViewDelegate, UITableViewDataSource {
    
    /* Storing all announcements */
    var announcements: [[String: Any]] = []
    
    /* For Expanding the cell */
    var isCellExpanded: Bool = false
    var selectedRowIndex: Int?
    
    @IBOutlet weak var announcementsTV: UITableView!
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        /* Display the nav bar */
        self.navigationController?.navigationBar.isHidden = false

        /* Customize the back button text for this view controller */
        let backButton = UIBarButtonItem()
        backButton.tintColor = UIColor.systemRed
        self.navigationController?.navigationBar.topItem?.backBarButtonItem = backButton
        
        /* Answering the delegate */
        self.announcementsTV.dataSource = self
        self.announcementsTV.delegate = self
        
        /* Styling the table view */
        self.announcementsTV.separatorStyle = .none
        
        /* Calling method to read announcements */
        self.readAnnouncementsFromDB { announcementsData in
            self.announcements = announcementsData
            self.announcementsTV.reloadData()
        }
        
    }

    
    /* Overriding the table view methods */
    func numberOfSections(in tableView: UITableView) -> Int {
        return self.announcements.count
    }
    
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return 1
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let cell = self.announcementsTV.dequeueReusableCell(withIdentifier: "announcementCell", for: indexPath) as! AnnouncementCell
         
        /* Apply the corner radius and mask to bounds to round the cell */
        cell.layer.cornerRadius = 12.0
        cell.layer.masksToBounds = true

        /* Set the background color of the cell */
        cell.contentView.backgroundColor = UIColor.white
        
        /* Spacing between the cells */
        cell.frame = cell.frame.inset(by: UIEdgeInsets(top: 60, left: 60, bottom: 60, right: 60))
        
        let data = self.announcements[indexPath.section]
        
        cell.titleLBL.text = data["title"] as? String
        cell.dateLBL.text = data["date"] as? String
        cell.announcementLBL.text = isCellExpanded && indexPath.row == selectedRowIndex ? data["message"] as? String: ""
        
        return cell
    }
    
    func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath) {
        self.announcementsTV.deselectRow(at: indexPath, animated: true)
        
        if selectedRowIndex == indexPath.row {
            isCellExpanded = !isCellExpanded
            selectedRowIndex = nil
        } else {
            isCellExpanded = true
            selectedRowIndex = indexPath.row
        }
        
        self.announcementsTV.reloadData()
    }
    
    func tableView(_ tableView: UITableView, heightForRowAt indexPath: IndexPath) -> CGFloat {
        return indexPath.row == selectedRowIndex ? 100 : 60
    }
    
    /* Spacing between the cells */
    func tableView(_ tableView: UITableView, heightForHeaderInSection section: Int) -> CGFloat {
        return 1.0
    }
    
    func tableView(_ tableView: UITableView, viewForHeaderInSection section: Int) -> UIView? {
        let headerView = UIView()
        headerView.backgroundColor = UIColor.clear
        return headerView
    }
}


extension AnnouncementsVC {
    /* Read all announcements from DB */
    func readAnnouncementsFromDB(completion: @escaping ([[String: Any]]) -> Void) {
        let announcementRef = UtilityConstants.db.collection("Announcements")
        
        announcementRef.getDocuments { (querySnapshot, error) in
            if let e = error {
                print(e.localizedDescription)
                return
            }
            
            var data: [[String: Any]] = []
            
            for document in querySnapshot!.documents {
                let announcement = document.data()
                if let announcementMessages = announcement["announcements"] {
                    data.append(contentsOf: announcementMessages as! [[String: Any]])
                }
            }
            completion(data)
        }
    }
}
