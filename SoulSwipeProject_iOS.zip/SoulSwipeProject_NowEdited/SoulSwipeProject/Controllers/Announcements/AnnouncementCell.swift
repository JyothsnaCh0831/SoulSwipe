//
//  AnnouncementCell.swift
//  SoulSwipeProject
//
//  Created by Jyothsna on 11/5/23.
//

import UIKit

class AnnouncementCell: UITableViewCell {

    @IBOutlet weak var titleLBL: UILabel!
    
    @IBOutlet weak var dateLBL: UILabel!
    
    @IBOutlet weak var announcementLBL: UILabel!
    
    override func awakeFromNib() {
        super.awakeFromNib()
    }

    override func setSelected(_ selected: Bool, animated: Bool) {
        super.setSelected(selected, animated: animated)
    }

}
