//
//  HomeVC.swift
//  SoulSwipeProject
//
//  Created by Jyothsna on 11/2/23.
//

import UIKit
import FirebaseAuth

class HomeVC: UIViewController, UICollectionViewDelegate, UICollectionViewDataSource {
    
    /* Storing all users */
    var usersDetails: [[String: Any]] = []
    
    /* Storing the favorites */
    var favorites: [String] = []
    
    /* Storing Compatibility Scores */
    var compatibilityScores: [String: Double] = [:]
    var sortedProfileScores: [(String, Double)] = []
    
    /* Declaring loading indicator */
    var compatibilityScoresLoadingIndicator: UIActivityIndicatorView!
    
    @IBOutlet weak var partnerCV: UICollectionView!
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        self.navigationItem.title = "Home"
        
        /* Customize the back button text for this view controller */
        self.navigationController?.navigationBar.isHidden = true
        
        /* Answering the collection view delegate */
        self.partnerCV.dataSource = self
        self.partnerCV.delegate = self
        
        /* Setting the layout */
        self.partnerCV.collectionViewLayout = self.setLayout()
        
        /* Getting the users of preferred gender */
        self.readDocumentsFromDB { userData in
            self.usersDetails = userData
            self.partnerCV.reloadData()
        }
        
        /* Calling method to read favorite profiles */
        self.getFavoritesOfUser { profiles in
            self.favorites = profiles
            self.partnerCV.reloadData()
        }
        
        /* Calculating compatibility percentage */
        self.calculateCompatabilityScore { scores in
            self.sortedProfileScores = scores
            
            print("Scores = ", self.sortedProfileScores)
            
            /* arrange usersDetails */
            let top5Keys = Array(scores.prefix(5)).map { $0.0 }
            var arrangedUsersDetails: [[String: Any]] = []
            
            for key in top5Keys {
                if let userDetails = self.usersDetails.first(where: { $0["email"] as? String == key }) {
                    arrangedUsersDetails.append(userDetails)
                }
            }
            
            let remainingUsersDetails = self.usersDetails.filter { !top5Keys.contains($0["email"] as? String ?? "") }
            arrangedUsersDetails += remainingUsersDetails
            
            // Now, arrangedUsersDetails contains the desired order
            self.usersDetails = arrangedUsersDetails
            print("User Details = ", self.usersDetails)
        }
        
        /* Calling method to read favorite profiles */
        self.getFavoritesOfUser { profiles in
            self.favorites = profiles
            self.partnerCV.reloadData()
        }
    }
    
    override func viewWillAppear(_ animated: Bool) {
        super.viewWillAppear(animated)
        
        /* Customize the back button text for this view controller */
        self.navigationController?.navigationBar.isHidden = true
        
        /* Getting the users of preferred gender */
        self.readDocumentsFromDB { userData in
            self.usersDetails = userData
            self.partnerCV.reloadData()
        }
        
        /* Calling method to read favorite profiles */
        self.getFavoritesOfUser { profiles in
            self.favorites = profiles
            self.partnerCV.reloadData()
        }
        
        // Set up the loading indicator
        compatibilityScoresLoadingIndicator = UIActivityIndicatorView(style: .large)
        compatibilityScoresLoadingIndicator.center = view.center
        compatibilityScoresLoadingIndicator.hidesWhenStopped = true
        view.addSubview(compatibilityScoresLoadingIndicator)
        
        /* Calculating compatibility percentage */
        self.calculateCompatabilityScore { scores in
            self.sortedProfileScores = scores
            
            /* arrange usersDetails */
            let top5Keys = Array(scores.prefix(5)).map { $0.0 }
            var arrangedUsersDetails: [[String: Any]] = []
            
            for key in top5Keys {
                if let userDetails = self.usersDetails.first(where: { $0["email"] as? String == key }) {
                    arrangedUsersDetails.append(userDetails)
                }
            }
            
            let remainingUsersDetails = self.usersDetails.filter { !top5Keys.contains($0["email"] as? String ?? "") }
            arrangedUsersDetails += remainingUsersDetails
            
            // Now, arrangedUsersDetails contains the desired order
            self.usersDetails = arrangedUsersDetails
        }
    }
    
    /* Overriding the collection view methods */
    func numberOfSections(in collectionView: UICollectionView) -> Int {
        return 2
    }
    
    func collectionView(_ collectionView: UICollectionView, numberOfItemsInSection section: Int) -> Int {
        switch section {
        case 0:
            return min(5, self.usersDetails.count)
        case 1:
            return max(0, self.usersDetails.count - 5)
        default:
            return 0
        }
    }
    
    func collectionView(_ collectionView: UICollectionView, cellForItemAt indexPath: IndexPath) -> UICollectionViewCell {
        
        let cell = self.partnerCV.dequeueReusableCell(withReuseIdentifier: "partnerCell", for: indexPath) as! PartnerSeekerCell
        
        switch indexPath.section {
        case 0:
            let user = self.usersDetails[indexPath.row]
            
            cell.partnerProfile.partnerImage.tag = indexPath.row
            if let data = UserDefaults.standard.data(forKey: user["email"] as! String) {
                let decoded = try! PropertyListDecoder().decode(Data.self, from: data)
                cell.partnerProfile.partnerImage.image = UIImage(data: decoded)
            }
            
            /* Adding tap gesture */
            cell.partnerProfile.partnerImage.isUserInteractionEnabled = true
            let tap = UITapGestureRecognizer(target: self, action: #selector(showPartnerProfile(_:)))
            tap.numberOfTapsRequired = 1
            cell.partnerProfile.partnerImage.addGestureRecognizer(tap)
            
            /* Name of the partner*/
            cell.partnerProfile.partnerName.text = user["fullName"] as? String
            
            /* Compatibility Score */
            if let email = user["email"] as? String, let score = compatibilityScores[email] {
                let roundedScore = Int(score.rounded())
                cell.partnerProfile.quizScoreLBL.text = "\(roundedScore)%"
            } else {
                cell.partnerProfile.quizScoreLBL.text = "N/A"
            }
            
            /* Getting likes count */
            cell.partnerProfile.partnerLikesCount.text = "\(user["likes"] as! Int) Likes"
            
            /* Adding tap gesture */
            cell.partnerProfile.likeLBL.text = "♡"
            cell.partnerProfile.likeLBL.tag = indexPath.row
            
            /* Check if exists in favorites */
            if(self.favorites.contains(user["email"] as! String) == true) {
                cell.partnerProfile.likeLBL.text = "♥"
            } else {
                cell.partnerProfile.likeLBL.text = "♡"
            }
            cell.partnerProfile.likeLBL.isUserInteractionEnabled = true
            let likeTap = UITapGestureRecognizer(target: self, action: #selector(likePartner(_:)))
            likeTap.numberOfTapsRequired = 1
            cell.partnerProfile.likeLBL.addGestureRecognizer(likeTap)
            
        case 1:
            let user = self.usersDetails[5 + indexPath.row]
            
            cell.partnerProfile.partnerImage.tag = 5 + indexPath.row
            if let data = UserDefaults.standard.data(forKey: user["email"] as! String) {
                let decoded = try! PropertyListDecoder().decode(Data.self, from: data)
                cell.partnerProfile.partnerImage.image = UIImage(data: decoded)
            }
            
            /* Adding tap gesture */
            cell.partnerProfile.partnerImage.isUserInteractionEnabled = true
            let tap = UITapGestureRecognizer(target: self, action: #selector(showPartnerProfile(_:)))
            tap.numberOfTapsRequired = 1
            cell.partnerProfile.partnerImage.addGestureRecognizer(tap)
            
            /* Name of the partner*/
            cell.partnerProfile.partnerName.text = user["fullName"] as? String
            
            /* Compatibility Score */
            if let email = user["email"] as? String, let score = compatibilityScores[email] {
                let roundedScore = Int(score.rounded())
                cell.partnerProfile.quizScoreLBL.text = "\(roundedScore)%"
            } else {
                cell.partnerProfile.quizScoreLBL.text = "N/A"
            }
            
            /* Getting likes count */
            cell.partnerProfile.partnerLikesCount.text = "\(user["likes"] as! Int) Likes"
            
            /* Adding tap gesture */
            cell.partnerProfile.likeLBL.text = "♡"
            cell.partnerProfile.likeLBL.tag = 5 + indexPath.row
            
            /* Check if exists in favorites */
            if(self.favorites.contains(user["email"] as! String) == true) {
                cell.partnerProfile.likeLBL.text = "♥"
            } else {
                cell.partnerProfile.likeLBL.text = "♡"
            }
            cell.partnerProfile.likeLBL.isUserInteractionEnabled = true
            let likeTap = UITapGestureRecognizer(target: self, action: #selector(likePartner(_:)))
            likeTap.numberOfTapsRequired = 1
            cell.partnerProfile.likeLBL.addGestureRecognizer(likeTap)
        default:
            print()
        }
        
        return cell
        
    }
    
    /* Collection View Layout */
    func setLayout() -> UICollectionViewCompositionalLayout {
        let layout = UICollectionViewCompositionalLayout { _,_ -> NSCollectionLayoutSection? in
            let item = NSCollectionLayoutItem(
                layoutSize: NSCollectionLayoutSize(
                    widthDimension: .fractionalWidth(1),
                    heightDimension: .fractionalHeight(1)
                )
            )
            item.contentInsets = NSDirectionalEdgeInsets(top: 10, leading: 10, bottom: 10, trailing: 10)
            
            let verticalStackGroup = NSCollectionLayoutGroup.horizontal(
                layoutSize: NSCollectionLayoutSize(
                    widthDimension: .fractionalWidth(0.8),
                    heightDimension: .fractionalHeight(1/2)
                ),
                repeatingSubitem: item,
                count: 1
            )
            
            let section = NSCollectionLayoutSection(group: verticalStackGroup)
            section.orthogonalScrollingBehavior = .continuousGroupLeadingBoundary
            return section
        }
        return layout
    }
    
    /* Adding Liked Partner to Favorites */
    @objc func likePartner(_ sender: UITapGestureRecognizer) {
        if let view = sender.view as? UILabel, let text = view.text {
            if(text == "♡") {
                /* Add to favorites in DB */
                self.updateInDB(at: view.tag)
                
                /* Increment the likes count in profile */
                self.updateLikesDetailsInDB(for: view.tag, with: "Increment")
                
                view.text = "♥"
                
            } else {
                /* Remove profile from DB */
                self.removeFromDB(at: view.tag)
                
                /* Decrement the likes count in profile */
                self.updateLikesDetailsInDB(for: view.tag, with: "Decrement")
                
                view.text = "♡"
                
            }
        }
    }
    
    /* Navigating to Partner Profile */
    @objc func showPartnerProfile(_ sender: UITapGestureRecognizer) {
        self.performSegue(withIdentifier: "showPartnerProfileScreen", sender: sender.view)
    }
    
    /* Sending data to next controller */
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        if let identifier = segue.identifier, identifier == "showPartnerProfileScreen" {
            let destinationVC = segue.destination as! PartnerProfileScreen
            if let view = sender as? UIImageView {
                destinationVC.userDetails = self.usersDetails[view.tag]
            }
        }
    }
    
}

extension HomeVC {
    /* Read all users from DB */
    func readDocumentsFromDB(completion: @escaping ([[String: Any]]) -> Void) {
        
        /* Get current user email */
        guard let user = Auth.auth().currentUser, let email = user.email else {
            return
        }
        
        UtilityConstants.db.collection("Users").document(email).getDocument {
            (document, error) in
            if let e = error {
                print(e.localizedDescription)
            }
            
            if let document = document, document.exists {
                if document.data() != nil {
                    let preferredGender = document.data()?["partnerGender"]
                    
                    UtilityConstants.db.collection("Users").whereField("gender", isEqualTo: preferredGender as Any).getDocuments {
                        (querySnapshot, error) in
                        if let e = error {
                            print(e.localizedDescription)
                        }
                        
                        var userData: [[String: Any]] = []
                        for document in querySnapshot!.documents {
                            userData.append(document.data())
                        }
                        completion(userData)
                    }
                }
            }
        }
    }
    
    
    /* Add the partner profile to the favorites */
    private func updateInDB(at index: Int) {
        
        /* Get current user email */
        guard let user = Auth.auth().currentUser, let email = user.email else {
            return
        }
        
        /* Get the profile */
        let profile = self.usersDetails[index]
        
        /* Getting the collection */
        UtilityConstants.db.collection("FavouriteUsers").document(email).getDocument {
            (snapshot, error) in
            if let e = error {
                print(e.localizedDescription)
            }
            
            /* Getting the existing profiles */
            if let document = snapshot, document.exists {
                if var dataArray = document.get("profiles") as? [String] {
                    guard let partnerEmail = profile["email"] as? String else{
                        return
                    }
                    
                    /* If not exists, add the profile */
                    if !dataArray.contains(partnerEmail) {
                        dataArray.append(partnerEmail)
                    }
                    
                    /* Update the array in the document */
                    UtilityConstants.db.collection("FavouriteUsers").document(email).updateData(
                        [
                            "profiles": dataArray
                        ]
                    ) { error in
                        if let e = error {
                            print(e.localizedDescription)
                        }
                    }
                }
            } else {
                
                /* If there is no document, create document */
                UtilityConstants.db.collection("FavouriteUsers").document(email).setData(
                    [
                        "profiles": [profile["email"]!]
                    ]
                ) { error in
                    if let e = error {
                        print(e.localizedDescription)
                    }
                }
            }
        }
    }
    
    /* Increment the likes count for profile in DB */
    private func updateLikesDetailsInDB(for index: Int, with flag: String) {
        
        /* Get current user email */
        guard let user = Auth.auth().currentUser, let email = user.email else {
            return
        }
        
        /* Get the profile */
        let profile = self.usersDetails[index]
        
        /* Getting the collection */
        UtilityConstants.db.collection("Users").document(profile["email"] as! String).getDocument {
            (snapshot, error) in
            if let e = error {
                print(e.localizedDescription)
            }
            
            /* Get the exisiting likes count */
            if let document = snapshot, document.exists {
                if var likesCount = document.get("likes") as? Int, var likedByProfiles = document.get("likedBy") as? [String] {
                    guard let partnerEmail = profile["email"] as? String else{
                        return
                    }
                    
                    /* Increment or Decrement based on flag value */
                    if(flag == "Increment") {
                        
                        /* If not exists, add the profile */
                        if !likedByProfiles.contains(email) {
                            likedByProfiles.append(email)
                            likesCount += 1
                        }
                    } else {
                        
                        /* Remove the profile*/
                        if let index = likedByProfiles.firstIndex(of: email) {
                            likedByProfiles.remove(at: index)
                            likesCount -= 1
                        }
                    }
                    
                    /* Update the likes count in the document */
                    UtilityConstants.db.collection("Users").document(partnerEmail).updateData(
                        [
                            "likes": likesCount,
                            "likedBy": likedByProfiles
                        ]
                    ) { error in
                        if let e = error {
                            print(e.localizedDescription)
                        }
                    }
                }
            }
        }
    }
    
    
    /* Remove profile from favorites in DB */
    private func removeFromDB(at index : Int){
        
        /* Get current user email */
        guard let user = Auth.auth().currentUser, let email = user.email else {
            return
        }
        
        /* Get the profile */
        let profile = self.usersDetails[index]
        
        /* Getting the collection */
        UtilityConstants.db.collection("FavouriteUsers").document(email).getDocument { (snapshot, error) in
            if let e = error {
                print(e.localizedDescription)
            }
            
            /* Getting the existing profiles */
            if let document = snapshot, document.exists {
                if var dataArray = document.get("profiles") as? [String] {
                    guard let partnerEmail = profile["email"] as? String else{
                        return
                    }
                    
                    /* Remove the profile*/
                    if let index = dataArray.firstIndex(of: partnerEmail) {
                        dataArray.remove(at: index)
                    }
                    
                    /* Update the array in the document */
                    UtilityConstants.db.collection("FavouriteUsers").document(email).updateData(
                        [
                            "profiles": dataArray
                        ]
                    ) { error in
                        if let e = error {
                            print(e.localizedDescription)
                        }
                    }
                }
            }
        }
    }
    
    /* Get all the favorites profiles of current user */
    private func getFavoritesOfUser(completion: @escaping ([String]) -> Void) {
        /* Current user email */
        guard let user = Auth.auth().currentUser, let email = user.email else {
            return
        }
        
        let usersRef = UtilityConstants.db.collection("FavouriteUsers").document(email)
        usersRef.getDocument { (document, error) in
            if let e = error {
                print(e.localizedDescription)
            }
            
            if let document = document, document.exists {
                if let data = document.data()!["profiles"] as? [String] {
                    completion(data)
                }
            }
        }
    }
}

extension HomeVC{
    private func fetchCurrentUserCompatabilityQuizAnswers(completion: @escaping ([String: [String]]) -> Void) {
        /* Current user email */
        guard let user = Auth.auth().currentUser, let email = user.email else {
            return
        }
        
        UtilityConstants.db.collection("CompatibilityQuiz").document(email).getDocument { (document, error) in
            if let error = error {
                print("Error getting document: \(error.localizedDescription)")
                return
            }
            
            if let document = document, document.exists {
                if let data = document.data() {
                    for key in data.keys {
                        if let values = data[key] as? [String] {
                            UtilityConstants.currentUserQuizAnswers[key] = values
                            /* for value in values {
                             print("Value: \(value)")
                             }*/
                        }else {
                            print("Values for this key are not in the expected format (Array<String>).")
                        }
                    }
                    //print(UtilityConstants.currentUserQuizAnswers)
                }else {
                    print("Document data is not in the expected format.")
                }
            } else {
                print("Document does not exist.")
            }
            DispatchQueue.global().asyncAfter(deadline: .now() + 0.25) {
                completion(UtilityConstants.currentUserQuizAnswers)
            }
        }
    }
    
    private func fetchOtherUsersCompatabilityQuizAnswers(completion: @escaping ([String: [[String: [String]]]]) -> Void) {
        /* Current user email */
        guard let user = Auth.auth().currentUser, let email = user.email else {
            return
        }
        
        UtilityConstants.db.collection("CompatibilityQuiz").getDocuments { (querySnapshot, error) in
            if let error = error {
                print("Error getting documents: \(error.localizedDescription)")
                return
            }
            
            guard let documents = querySnapshot?.documents else {
                print("No documents found in the collection.")
                return
            }
            
            let filteredDocuments = documents.filter { $0.documentID != email }
            for document in filteredDocuments {
                let data = document.data()
                var dataArray: [[String: [String]]] = []
                for (key, value) in data {
                    if let stringArray = value as? [String] {
                        let innerDictionary: [String: [String]] = [key: stringArray]
                        dataArray.append(innerDictionary)
                    }
                }
                UtilityConstants.otherUsersQuizAnswers[document.documentID] = dataArray
            }
            //print(UtilityConstants.otherUsersQuizAnswers)
            DispatchQueue.global().asyncAfter(deadline: .now() + 0.25) {
                completion(UtilityConstants.otherUsersQuizAnswers)
            }
        }
    }
    
    func fetchUserGenderData(completion: @escaping ([String: String], String?) -> Void) {
        /* Current user email */
        guard let user = Auth.auth().currentUser, let currentUserEmail = user.email else {
            return
        }
        
        var genderData = [String: String]()
        var currentUserPreferredGender = ""
        
        UtilityConstants.db.collection("Users").getDocuments { (querySnapshot, error) in
            if let error = error {
                print("Error getting documents: \(error)")
            } else {
                for document in querySnapshot!.documents {
                    let email = document.documentID
                    //print(email)
                    if let gender = document.data()["gender"] as? String, let preferredGender = document.data()["partnerGender"] as? String {
                        if email != currentUserEmail {
                            genderData[email] = gender
                        }else{
                            currentUserPreferredGender = preferredGender
                        }
                    }
                }
                //print(genderData)
            }
            DispatchQueue.global().asyncAfter(deadline: .now() + 0.25) {
                completion(genderData, currentUserPreferredGender)
            }
        }
    }
    
    private func storeCompatibilityScores(scores: [(email: String, score: Double)], completion: @escaping (Error?) -> Void) {
        guard let currentUser = Auth.auth().currentUser, let currentUserEmail = currentUser.email else {
            completion(NSError(domain: "AuthenticationError", code: 0, userInfo: [NSLocalizedDescriptionKey: "Current user not found"]))
            return
        }
        
        var scoresData: [String: Double] = [:]
        
        for (email, score) in scores {
            let roundedScore = Int(score.rounded())
            scoresData[email] = Double(roundedScore)
        }
        
        UtilityConstants.db.collection("CompatibilityScores").document(currentUserEmail).setData(scoresData) { error in
            completion(error)
        }
    }
    
    private func calculateCompatabilityScore(completion: @escaping ([(String, Double)]) -> Void) {
        var firestoreDataA: [String: [String]]?
        var firestoreDataB: [String: [[String: [String]]]]?
        var genderPreferences: [String: String]?
        var currentUserPreferredGender: String?
        
        fetchCurrentUserCompatabilityQuizAnswers { dataA in
            firestoreDataA = dataA
            //print(dataA)
            self.fetchOtherUsersCompatabilityQuizAnswers { dataB in
                firestoreDataB = dataB
                //print(dataB)
                self.fetchUserGenderData { (genderData, preferredGender) in
                    genderPreferences = genderData
                    currentUserPreferredGender = preferredGender
                    var emailScores: [(email: String, score: Double)] = []
                    
                    for (email, emailData) in firestoreDataB! {
                        if let userGender = genderPreferences?[email] {
                            
                            if userGender == currentUserPreferredGender! {
                                var totalScore: Double = 0.0
                                var totalQuestions: Double = 0.0
                                
                                for dictionary in emailData {
                                    for (keyA, firestoreValuesA) in firestoreDataA! {
                                        if let valuesB = dictionary[keyA] {
                                            let intersection = Set(firestoreValuesA).intersection(valuesB)
                                            let union = Set(firestoreValuesA).union(valuesB)
                                            let questionScore: Double = Double(intersection.count) / Double(union.count)
                                            
                                            totalScore += questionScore
                                            totalQuestions += 1.0
                                        }
                                    }
                                }
                                let score: Double = totalQuestions > 0 ? ((totalScore / totalQuestions) * 100).rounded(toPlaces: 2) : 0.0
                                emailScores.append((email: email, score: score))
                            }
                        }
                    }
                    for (email, score) in emailScores {
                        self.compatibilityScores[email] = score
                        print("Email: \(email), Score: \(score)")
                    }
                    
                    //self.compatibilityScoresLoadingIndicator.stopAnimating()
                    DispatchQueue.main.async {
                        self.compatibilityScoresLoadingIndicator.stopAnimating()
                        self.partnerCV.reloadData()
                    }
                    
                    /* Store scores in Firestore */
                    self.storeCompatibilityScores(scores: emailScores) { error in
                        if let error = error {
                            print("Error storing compatibility scores: \(error.localizedDescription)")
                        } else {
                            print("Compatibility scores stored successfully.")
                            self.partnerCV.reloadData()
                        }
                    }
                    
                    /* Sort the scores */
                    let sortedScores = self.compatibilityScores.sorted { $0.value > $1.value }
                    
                    completion(sortedScores)
                }
            }
        }
    }
}

extension Double{
    func rounded(toPlaces places: Int) -> Double {
        let divisor = pow(10.0, Double(places))
        return (self * divisor).rounded() / divisor
    }
}
