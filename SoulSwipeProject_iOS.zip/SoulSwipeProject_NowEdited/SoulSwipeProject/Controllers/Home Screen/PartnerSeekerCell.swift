//
//  PartnerSeekerCell.swift
//  SoulSwipeProject
//
//  Created by Jyothsna on 11/4/23.
//

import UIKit

class PartnerSeekerCell: UICollectionViewCell {
    

    @IBOutlet weak var partnerProfile: PartnerSeekerCellView!
    
}
