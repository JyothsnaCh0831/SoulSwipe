//
//  PartnerSeekerCell.swift
//  SoulSwipeProject
//
//  Created by Jyothsna on 11/4/23.
//

import UIKit

class PartnerSeekerCellView: UIView {
    
    @IBOutlet weak var partnerImage: UIImageView! {
        didSet {
            /* Styling the image */
            self.partnerImage.layer.cornerRadius = 15.0
            self.partnerImage.layer.masksToBounds = true
        }
    }
    
    
    @IBOutlet weak var quizScoreLBL: UILabel!
    
    @IBOutlet weak var likeLBL: UILabel!
    
    @IBOutlet weak var partnerName: UILabel!
    
    @IBOutlet weak var partnerLikesCount: UILabel!
    
    override init(frame: CGRect) {
        super.init(frame: frame)
        self.setUpXibView()
    }
    
    required init?(coder: NSCoder) {
        super.init(coder: coder)
        self.setUpXibView()
    }
    
    private func setUpXibView(){
        let viewOfXib = Bundle.main.loadNibNamed("PartnerSeekerCell", owner: self)![0] as! UIView
        viewOfXib.frame = self.bounds
        self.addSubview(viewOfXib)
    }
}
