//
//  PartnerProfileScreen.swift
//  SoulSwipeProject
//
//  Created by Jyothsna on 10/24/23.
//

import UIKit
import FirebaseAuth
import CometChatUIKitSwift
import CometChatSDK

class PartnerProfileScreen: UIViewController {
    
    var userDetails: [String: Any] = [:]
    
    @IBOutlet weak var partnerIMG: UIImageView! {
        didSet {
            /* Styling the image */
            self.partnerIMG.layer.cornerRadius = 15.0
            self.partnerIMG.layer.masksToBounds = true
        }
    }
    
    @IBOutlet weak var partnerName: UILabel!
    
    @IBOutlet weak var partnerProfession: UILabel!
    
    @IBOutlet weak var bioTV: UITextView!
    
    @IBOutlet weak var reportBtn: UIBarButtonItem!
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        /* Display the nav bar */
        self.navigationController?.navigationBar.isHidden = false
        
        /* Customize the back button text for this view controller */
        let backButton = UIBarButtonItem()
        backButton.tintColor = UIColor.systemRed
        self.navigationController?.navigationBar.topItem?.backBarButtonItem = backButton
        
        /* Display the details */
        if let data = UserDefaults.standard.data(forKey: self.userDetails["email"] as! String) {
            let decoded = try! PropertyListDecoder().decode(Data.self, from: data)
            self.partnerIMG.image = UIImage(data: decoded)
        }

        self.partnerName.text = self.userDetails["fullName"] as? String
        self.partnerProfession.text = self.userDetails["job"] as? String
        self.bioTV.text = self.userDetails["aboutMe"] as? String
        
        /* Check if the partner is already reported or not */
        self.checkReportedOrNot(for: self.userDetails["email"] as! String)
    }
    
    @IBAction func startChat(_ sender: UIButton) {
        let cometChatMessages = CometChatMessages()
        
        guard let uid = self.userDetails["cometchatID"] as? String, let name = self.userDetails["fullName"] as? String else{return}
        
        let user = User(uid: uid, name: name)
        cometChatMessages.set(user: user)
        self.present(cometChatMessages, animated: true)
    }
    
    
    @IBAction func onClickReport(_ sender: UIBarButtonItem) {
        /* Display an alert */
        let alert = UIAlertController(title: "Report", message: "Are you sure you want to report this partner seeker?", preferredStyle: .alert)
        
        let reportAction = UIAlertAction(title: "Yes", style: .destructive, handler: {_ in
            /* if yes, increment the count of reports */
            self.incrementReportsCount(for: self.userDetails["email"] as! String)
            
            /* Add the partner seeker to reports array of current user */
            self.addPartnerToReports(for: self.userDetails["email"] as! String)
            
            /* Change the title of the button */
            sender.title = "Reported"
            
            /* Make the button disable */
            sender.isEnabled = false
        })
        
        let cancelAction = UIAlertAction(title: "Cancel", style: .cancel, handler: nil)
        
        alert.addAction(reportAction)
        alert.addAction(cancelAction)
        
        self.present(alert, animated: true)
    }
    
    /* Checking the partner seeker reported or not */
    private func checkReportedOrNot(for partnerEmail: String) {
        
        /* Get current user email */
        guard let user = Auth.auth().currentUser, let email = user.email else {
            return
        }
        
        /* Getting the collection */
        UtilityConstants.db.collection("Reports").document(email).getDocument {
            (snapshot, error) in
            if let e = error {
                print(e.localizedDescription)
            }
            
            /* Getting the existing profiles */
            if let document = snapshot, document.exists {
                if let dataArray = document.get("profiles") as? [String] {
                    
                    /* If exists, change the button title */
                    if dataArray.contains(partnerEmail) {
                        self.reportBtn.title = "Reported"
                        self.reportBtn.isEnabled = false
                    }
                }
            }
        }
    }
    
    
    /* Increment the reports count for partner seeker */
    private func incrementReportsCount(for partnerEmail: String) {
        
        /* Get current user email */
        guard let user = Auth.auth().currentUser, let email = user.email else {
            return
        }
        
        /* Get the existing count of reports */
        UtilityConstants.db.collection("Users").document(partnerEmail).getDocument {
            (snapshot, error) in
            if let e = error {
                print(e.localizedDescription)
            }
            
            /* Get the exisiting reprots count */
            if let document = snapshot, document.exists {
                if var reportsCount = document.get("reports") as? Int, var reportedByProfiles = document.get("reportedBy") as? [String] {
                    
                    reportsCount += 1
                    reportedByProfiles.append(email)
                    
                    /* Update the likes count in the document */
                    UtilityConstants.db.collection("Users").document(partnerEmail).updateData(
                        [
                            "reports": reportsCount,
                            "reportedBy": reportedByProfiles
                        ]
                    ) { error in
                        if let e = error {
                            print(e.localizedDescription)
                        }
                    }
                }
            }
        }
    }
    
    /* Add partner seeker to the reports collection*/
    private func addPartnerToReports(for partnerEmail: String) {
        
        /* Get current user email */
        guard let user = Auth.auth().currentUser, let email = user.email else {
            return
        }
        
        /* Getting the collection */
        UtilityConstants.db.collection("Reports").document(email).getDocument {
            (snapshot, error) in
            if let e = error {
                print(e.localizedDescription)
            }
            
            /* Getting the existing profiles */
            if let document = snapshot, document.exists {
                if var dataArray = document.get("profiles") as? [String] {
                
                    /* If not exists, add the profile */
                    if !dataArray.contains(partnerEmail) {
                        dataArray.append(partnerEmail)
                    }
                    
                    /* Update the array in the document */
                    UtilityConstants.db.collection("Reports").document(email).updateData(
                        [
                            "profiles": dataArray
                        ]
                    ) { error in
                        if let e = error {
                            print(e.localizedDescription)
                        }
                    }
                }
            } else {
                
                /* If there is no document, create document */
                UtilityConstants.db.collection("Reports").document(email).setData(
                    [
                        "profiles": [partnerEmail]
                    ]
                ) { error in
                    if let e = error {
                        print(e.localizedDescription)
                    }
                }
            }
        }
    }
}

