//
//  ProfileOptionsCell.swift
//  SoulSwipeProject
//
//  Created by Jyothsna on 10/18/23.
//

import UIKit

class ProfileOptionsCell: UITableViewCell {
    
    
    @IBOutlet weak var optionImage: UIImageView!
    
    @IBOutlet weak var optionNameLBL: UILabel!
    
    override func awakeFromNib() {
        super.awakeFromNib()
        // Initialization code
    }

    override func setSelected(_ selected: Bool, animated: Bool) {
        super.setSelected(selected, animated: animated)

        // Configure the view for the selected state
    }

}
