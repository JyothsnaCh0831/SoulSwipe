//
//  EditProfileVC.swift
//  SoulSwipeProject
//
//  Created by Jyothsna on 10/22/23.
//

import UIKit
import FirebaseAuth
import FirebaseFirestore

class EditProfileVC: UIViewController, UIImagePickerControllerDelegate, UINavigationControllerDelegate {
    
    @IBOutlet weak var personIV: UIImageView! {
        didSet {
            self.personIV.isUserInteractionEnabled = true
            
            let singleTap = UITapGestureRecognizer(target: self, action: #selector(editImage(_:)))
            singleTap.numberOfTapsRequired = 1
            self.personIV.addGestureRecognizer(singleTap)
            
            /* Styling the image */
            self.personIV.layer.cornerRadius = 15.0
            self.personIV.layer.masksToBounds = true
        }
    }
    
    @IBOutlet weak var firstNameTF: UITextField!
    
    @IBOutlet weak var lastNameTF: UITextField!
    
    @IBOutlet var genderBtns: [UIButton]!
    
    @IBOutlet weak var professionTF: UITextField!
    
    @IBOutlet weak var emailTF: UITextField!
    
    @IBOutlet weak var monthTF: UITextField!
    
    @IBOutlet weak var dayTF: UITextField!
    
    @IBOutlet weak var yearTF: UITextField!
    
    @IBOutlet weak var bioTV: UITextView!
    
    @IBOutlet var textFields: [UITextField]!
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        /* Display the nav bar */
        self.navigationController?.navigationBar.isHidden = false

        /* Customize the back button text for this view controller */
        let backButton = UIBarButtonItem()
        backButton.tintColor = UIColor.systemRed
        self.navigationController?.navigationBar.topItem?.backBarButtonItem = backButton
        
        
        /* Calling method to styles all the text fields */
        self.styleTextFields(using: self.textFields)
        
        /* Styling the text view */
        self.bioTV.layer.borderWidth = 1.5
        self.bioTV.layer.cornerRadius = 15.0
        self.bioTV.layer.masksToBounds = true
        self.bioTV.layer.borderColor = UIColor.lightGray.cgColor
        self.bioTV.isUserInteractionEnabled = true
        
        /* Disabling Email and Birthday for editing */
        self.emailTF.isEnabled = false
        self.monthTF.isEnabled = false
        self.dayTF.isEnabled = false
        self.yearTF.isEnabled = false
        
        /* Getting data from DB */
        self.profileDetailsFromDB()
        
        /* Displaying the image from UserDefaults */
        self.loadImage()
    }
    
    
    @IBAction func onClickUpdate(_ sender: UIButton) {
        
        /* Get the email of the user */
        guard let user = Auth.auth().currentUser, let email = user.email else {
            return
        }
        
        UtilityConstants.db.collection("Users").document(email).updateData(
            [
                "firstName": self.firstNameTF.text!,
                "lastName": self.lastNameTF.text!,
                "fullName": self.firstNameTF.text! + " " + self.lastNameTF.text!,
                "profession": self.professionTF.text!,
                "aboutMe": self.bioTV.text!
            ]
        ) { error in
            if let e = error {
                print(e.localizedDescription)
            } else {
                UtilityConstants.displayAlert(for: self, having: "Success", with: "Your Profile is updated successfully😃", and: UtilityConstants.defaultAction)
            }
        }
    }
    
    
    /* Styling all the text fields */
    private func styleTextFields(using sender: [UITextField]!) {
        sender.forEach {
            textField in
            
            /* Clearing all borders */
            textField.borderStyle = .none
            
            /* Adding only bottom border */
            let bottomBorder = CALayer()
            let borderWidth: CGFloat = 1.5
            bottomBorder.borderColor = UIColor.lightGray.cgColor
            bottomBorder.frame = CGRect(x: 0, y: textField.frame.size.height - borderWidth, width: textField.frame.size.width, height: borderWidth)
            bottomBorder.borderWidth = borderWidth
            textField.layer.addSublayer(bottomBorder)
            textField.layer.masksToBounds = true
        }
    }
}
extension EditProfileVC {
    
    /* Gettings details from the Firestore */
    private func profileDetailsFromDB() {
        
        /* Get the email of the user */
        guard let user = Auth.auth().currentUser, let email = user.email else {
            print("User mail is empty")
            return
        }
        
        /* Details from DB */
        let usersRef = UtilityConstants.db.collection("Users").document(email)
        
        usersRef.getDocument {
            (document, error) in
            if let document = document, document.exists, let details = document.data() {
                
                /* Name details */
                self.firstNameTF.text = details["firstName"] as? String
                self.lastNameTF.text = details["lastName"] as? String
                
                /* Gender */
                if(details["gender"] as? String == "Male") {
                    self.genderBtns[1].tintColor = .systemRed
                } else {
                    self.genderBtns[0].tintColor = .systemRed
                }
                
                /* Profession */
                self.professionTF.text = details["profession"] as? String
                
                /* Email address */
                self.emailTF.text = details["email"] as? String
                
                /* Birthday date*/
                if let birthday = details["birthday"] as? String {
                    self.yearTF.text = birthday.components(separatedBy: "/")[0]
                    self.monthTF.text = birthday.components(separatedBy: "/")[1]
                    self.dayTF.text = birthday.components(separatedBy: "/")[2]
                }
                
                /* About Me */
                self.bioTV.text = details["aboutMe"] as? String
            }
        }
    }
    
    /* Edit the image */
    @objc func editImage(_ sender: UITapGestureRecognizer) {
        
        /* Create an image picker controller */
        let imagePicker = UIImagePickerController()
        
        /* Answering the picker view delegate */
        imagePicker.delegate = self
        
        /* Source to select the images */
        imagePicker.sourceType = .photoLibrary
        
        /* Present the image picker */
        present(imagePicker, animated: true, completion: nil)
    }
    
    /* Implement the image picker delegate methods */
    func imagePickerController(_ picker: UIImagePickerController, didFinishPickingMediaWithInfo info: [UIImagePickerController.InfoKey : Any]) {
        if let selectedImage = info[.originalImage] as? UIImage {
            self.personIV.image = selectedImage
            
            /* Storing the selected image to UserDefaults */
            guard let data = selectedImage.jpegData(compressionQuality: 0.5) else {
                return
            }
            let encoded = try! PropertyListEncoder().encode(data)
            UserDefaults.standard.set(encoded, forKey: Auth.auth().currentUser!.email!)
        }
        
        /* Dismiss the image picker */
        picker.dismiss(animated: true, completion: nil)
    }
    
    func imagePickerControllerDidCancel(_ picker: UIImagePickerController) {
        /* Dismiss the image picker without selecting an image */
        picker.dismiss(animated: true, completion: nil)
    }
    
    
    /* Load the image stored in UserDefaults */
    func loadImage() {
        guard let data = UserDefaults.standard.data(forKey: Auth.auth().currentUser!.email!) else {
            return
        }
        let decoded = try! PropertyListDecoder().decode(Data.self, from: data)
        self.personIV.image = UIImage(data: decoded)
    }
}
