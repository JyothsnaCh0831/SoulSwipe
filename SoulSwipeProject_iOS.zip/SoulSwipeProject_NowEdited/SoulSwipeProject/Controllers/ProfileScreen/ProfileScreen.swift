//
//  ProfileScreen.swift
//  SoulSwipeProject
//
//  Created by Jyothsna on 10/18/23.
//

import UIKit
import FirebaseAuth
import FirebaseFirestore

class ProfileScreen: UIViewController, UITableViewDelegate, UITableViewDataSource {
    
    @IBOutlet weak var profileIV: UIImageView!
    
    @IBOutlet weak var nameLBL: UILabel!
    
    @IBOutlet weak var editProfileBtn: UIButton!
    
    @IBOutlet weak var optionsTableView: UITableView!
    
    @IBOutlet weak var detailsSV: UIStackView!
    
    @IBOutlet weak var tableViewSV: UIStackView!
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        /* Display the nav bar */
        self.navigationController?.navigationBar.isHidden = true
        
        /* Answering the table view delegate */
        self.optionsTableView.dataSource = self
        self.optionsTableView.delegate = self
    
        
        /* Applying corner radius to the table view */
        self.optionsTableView.clipsToBounds = true
        self.optionsTableView.layer.cornerRadius = 25.0
        self.optionsTableView.layer.maskedCorners = [.layerMinXMinYCorner, .layerMaxXMinYCorner]
        
        /* Styling the table view */
        self.optionsTableView.separatorStyle = .none
        
        /* Image Styling */
        self.profileIV.layer.cornerRadius = 10.0
        self.profileIV.layer.masksToBounds = true
        
        /* Getting data from DB */
        self.profileDetailsFromDB()
    }
    
    override func viewWillAppear(_ animated: Bool) {
        super.viewWillAppear(animated)
        
        /* Display the nav bar */
        self.navigationController?.navigationBar.isHidden = true
        
        /* Load the image from UserDefaults */
        guard let user = Auth.auth().currentUser, let email = user.email else {
            return
        }
        if let data = UserDefaults.standard.data(forKey: email) {
            let decoded = try! PropertyListDecoder().decode(Data.self, from: data)
            self.profileIV.image = UIImage(data: decoded)
        }
    }
    
    
    @IBAction func onClickEditProfile(_ sender: UIButton) {
        /* Navigating to Edit Profile Screen */
        let edit = self.storyboard?.instantiateViewController(withIdentifier: "editProfileScreen")as! EditProfileVC
        self.navigationController?.pushViewController(edit, animated: true)
    }
    
    /* Handling the table view function */
    func numberOfSections(in tableView: UITableView) -> Int {
        return 1
    }
    
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return UtilityConstants.profileScreenOptions.count
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let cell = self.optionsTableView.dequeueReusableCell(withIdentifier: "options", for: indexPath) as! ProfileOptionsCell
        cell.optionNameLBL.text = UtilityConstants.profileScreenOptions[indexPath.row].option
        cell.optionImage.image = UIImage(systemName: UtilityConstants.profileScreenOptions[indexPath.row].image)
        cell.optionImage.tintColor = UIColor.red
        return cell
    }
    
    func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath) {
        self.optionsTableView.deselectRow(at: indexPath, animated: true)
        
        switch indexPath.row {
        case 0:
            /* Navigating to Likes Screen */
            self.performSegue(withIdentifier: "showLikedByProfilesScreen", sender: self)
            
        case 1:
            /* Navigating to Edit Questionnaire Screen */
            self.performSegue(withIdentifier: "showEditQuestionnaireScreen", sender: self)
            
        case 2:
            /* Navigating to Messages Screen */
            self.performSegue(withIdentifier: "showMessagesScreen", sender: self)
            
        case 3:
            /* Navigating to Announcements Screen */
            self.performSegue(withIdentifier: "showAnnouncementsScreen", sender: self)
            
        case 4:
            /* Allowing the user to reset his/her password */
            self.changePassword()
            
        case 5:
            /* Choice Alert */
            let choiceAlert = UIAlertController(title: "Delete Account", message: "Are you sure you want to delete your account?", preferredStyle: .alert)
            
            /* Choice alert actions */
            let deleteAction = UIAlertAction(title: "Delete", style: .destructive) { _ in
                /* Display confirm alert */
                let confirmAlert = UIAlertController(title: "Delete Account", message: "Deleting your account will result in the loss of your data, and you won't be able to access the app further. Are you sure you want to proceed?", preferredStyle: .alert)
                
                let proceedAction = UIAlertAction(title: "Proceed", style: .destructive) {_ in
                    self.updateDeleteOptionToDB()
                    
                    /* Perform Logout session */
                    UtilityConstants.alertForLogout(for: self)
                    
                }
                let cancelAction = UIAlertAction(title: "Cancel", style: .cancel, handler: nil)
                
                confirmAlert.addAction(proceedAction)
                confirmAlert.addAction(cancelAction)
                
                self.present(confirmAlert, animated: true)
                    
            }
            let cancelAction = UIAlertAction(title: "Cancel", style: .cancel, handler: nil)
            
            /* Adding the actions for choice alert */
            choiceAlert.addAction(deleteAction)
            choiceAlert.addAction(cancelAction)
            
            /* Displaying the choice alert */
            self.present(choiceAlert, animated: true)
        
        case 6:
            /* Perform Logout session */
            UtilityConstants.alertForLogout(for: self)
            
            /* Navigate to login screen */
            let login = self.storyboard?.instantiateViewController(withIdentifier: "loginScreen")as! LoginScreen
            self.navigationController?.pushViewController(login, animated: true)
        
        default:
            print()
        }
    }
    
    func tableView(_ tableView: UITableView, heightForRowAt indexPath: IndexPath) -> CGFloat {
        return 68
    }

}

extension ProfileScreen {
    
    /* Gettings details from the Firestore */
    private func profileDetailsFromDB() {
        
        /* Get the email of the user */
        guard let user = Auth.auth().currentUser, let email = user.email else {
            print("User mail is empty")
            return
        }
        
        /* Details from DB */
        let usersRef = UtilityConstants.db.collection("Users").document(email)
        
        usersRef.getDocument {
            (document, error) in
            if let document = document, document.exists, let details = document.data() {
                
                /* Name details */
                self.nameLBL.text = details["fullName"] as? String
            }
        }
    }
    
    /* Allowing the user to reset his/her password */
    private func changePassword() {
        
        /* Get the email of the user */
        guard let user = Auth.auth().currentUser, let email = user.email else {
            print("User mail is empty")
            return
        }
        
        /* Sending the link */
        Auth.auth().sendPasswordReset(withEmail: email) { error in
            if let e = error {
                print(e.localizedDescription)
            } else {
                UtilityConstants.displayAlert(for: self, having: "Success", with: "Reset password link is successfully send to your registered email.", and: UtilityConstants.defaultAction)
            }
        }
    }
    
    
    /* Update delete account details in DB */
    private func updateDeleteOptionToDB() {
        
        /* Get the email of the user */
        guard let user = Auth.auth().currentUser, let email = user.email else {
            print("User mail is empty")
            return
        }
        
        /* Permanently deleting the user authentication */
        Auth.auth().currentUser?.delete(completion: { (error) in
            if let e = error {
                print(e.localizedDescription)
            }
        })

        /* Update delete in DB */
        UtilityConstants.db.collection("Users").document(email).updateData(
            [
                "isAccountDeleted": true
            ]
        ) { error in
            if let e = error {
                print(e.localizedDescription)
            }
        }
    }
}
