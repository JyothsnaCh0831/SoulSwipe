//
//  FavoriteProfileCell.swift
//  SoulSwipeProject
//
//  Created by Jyothsna on 10/24/23.
//

import UIKit

class FavoriteProfileCell: UITableViewCell {
    
    @IBOutlet weak var profileIMG: UIImageView!
    
    @IBOutlet weak var profileName: UILabel!
    
    @IBOutlet weak var profileProfession: UILabel!
    
    override func awakeFromNib() {
        super.awakeFromNib()
        
    }

    override func setSelected(_ selected: Bool, animated: Bool) {
        super.setSelected(selected, animated: animated)
    }

}
