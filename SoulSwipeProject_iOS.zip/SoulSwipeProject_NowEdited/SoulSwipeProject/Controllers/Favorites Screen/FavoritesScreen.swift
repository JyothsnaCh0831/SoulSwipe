//
//  FavoritesScreen.swift
//  SoulSwipeProject
//
//  Created by Jyothsna on 10/24/23.
//

import UIKit
import FirebaseAuth

class FavoritesScreen: UIViewController, UITableViewDelegate, UITableViewDataSource {
    
    /* Storing the favorites */
    var favorites: [[String: Any]] = []
    var selectedParnterIndex: Int = 0
    var partnerEmail: String = ""
    
    @IBOutlet weak var favoritesTV: UITableView!
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        /* Display the nav bar */
        self.navigationController?.navigationBar.isHidden = true
        
        /* Customize the back button text for this view controller */
        let backButton = UIBarButtonItem()
        backButton.tintColor = UIColor.systemRed
        self.navigationController?.navigationBar.topItem?.backBarButtonItem = backButton

        /* Answering the delegate */
        self.favoritesTV.dataSource = self
        self.favoritesTV.delegate = self
        
        /* Styling the table view */
        self.favoritesTV.separatorStyle = .none
        
        /* Clearing the array */
        self.favorites.removeAll()
        
        /* Calling method to read favorite profiles */
        self.getFavoritesOfUser { profiles in
            self.favorites = profiles
            self.favoritesTV.reloadData()
        }
    }
    
    override func viewWillAppear(_ animated: Bool) {
        super.viewWillAppear(animated)
        
        /* Display the nav bar */
        self.navigationController?.navigationBar.isHidden = true
        
        /* Clearing the array */
        self.favorites.removeAll()
        
        /* Calling method to read favorite profiles */
        self.getFavoritesOfUser { profiles in
            self.favorites = profiles
            print("Favorites = ", self.favorites)
            self.favoritesTV.reloadData()
        }
    }
    
    
    /* Overriding the table view methods */
    func numberOfSections(in tableView: UITableView) -> Int {
        return self.favorites.count
    }
    
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return 1
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let cell = self.favoritesTV.dequeueReusableCell(withIdentifier: "favoriteProfiles", for: indexPath) as! FavoriteProfileCell
        
        /* Apply the corner radius and mask to bounds to round the cell */
        cell.layer.cornerRadius = 12.0
        cell.layer.masksToBounds = true

        /* Set the background color of the cell */
        cell.contentView.backgroundColor = UIColor.white
        
        let profile = self.favorites[indexPath.section]

        cell.profileName.text = profile["fullName"] as? String
        cell.profileProfession.text = profile["profession"] as? String
        
        /* Image */
        if let data = UserDefaults.standard.data(forKey: profile["email"] as! String) {
            let decoded = try! PropertyListDecoder().decode(Data.self, from: data)
            cell.profileIMG.image = UIImage(data: decoded)
        }
        cell.profileIMG.layer.cornerRadius = 10.0
        cell.profileIMG.layer.masksToBounds = true
        
        return cell
    }
    
    func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath) {
        self.favoritesTV.deselectRow(at: indexPath, animated: true)
        self.selectedParnterIndex = indexPath.section
        performSegue(withIdentifier: "showPartnerProfileScreen", sender: self)
    }
    
    func tableView(_ tableView: UITableView, leadingSwipeActionsConfigurationForRowAt indexPath: IndexPath) -> UISwipeActionsConfiguration? {
        let removeFromFavourites = UIContextualAction(style: .normal, title: "Remove", handler: {
            [weak self] (act, view, cmp) in
            self!.partnerEmail = self!.favorites[indexPath.section]["email"]! as! String
            self!.favorites.remove(at: indexPath.section)
            self!.favoritesTV.reloadData()
            self!.removeFavouriteFromDB()
            cmp(true)
        })
        removeFromFavourites.backgroundColor = UIColor.purple
        return UISwipeActionsConfiguration(actions: [removeFromFavourites])
    }
    
    func tableView(_ tableView: UITableView, heightForRowAt indexPath: IndexPath) -> CGFloat {
        return 75
    }
    
    /* Spacing between the cells */
    func tableView(_ tableView: UITableView, heightForHeaderInSection section: Int) -> CGFloat {
        return 1.0
    }
    
    func tableView(_ tableView: UITableView, viewForHeaderInSection section: Int) -> UIView? {
        let headerView = UIView()
        headerView.backgroundColor = UIColor.clear
        return headerView
    }
    
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        if let identifier = segue.identifier, identifier == "showPartnerProfileScreen" {
            let destinationVC = segue.destination as! PartnerProfileScreen
            destinationVC.userDetails = self.favorites[self.selectedParnterIndex]
        }
    }
}


extension FavoritesScreen {
    /* Get all the favorites profiles of current user */
    private func getFavoritesOfUser(completion: @escaping ([[String: Any]]) -> Void) {
        /* Current user email */
        guard let user = Auth.auth().currentUser, let email = user.email else {
            return
        }
        
        var profilesDetails: [[String: Any]] = []
        
        let usersRef = UtilityConstants.db.collection("FavouriteUsers").document(email)
        usersRef.getDocument { (document, error) in
            if let e = error {
                print(e.localizedDescription)
            }
            
            if let document = document, document.exists {
                if let data = document.data()!["profiles"] as? [String] {
                    for profile in data {
                        UtilityConstants.db.collection("Users").document(profile).getDocument { (document, error) in
                            if let e = error {
                                print(e.localizedDescription)
                            }
                        
                            if let document = document, document.exists {
                                if let data = document.data() {
                                    profilesDetails.append(data)
                                    print(profilesDetails)
                                }
                            }
                            completion(profilesDetails)
                        }
                    }
                }
            }
        }
    }
    
    /* Remove partner profile from favorites */
    private func removeFavouriteFromDB() {
       
        /* Current user email */
        guard let user = Auth.auth().currentUser, let email = user.email else {
            return
        }
        
        /* Getting the collection */
        let docRef = UtilityConstants.db.collection("FavouriteUsers").document(self.partnerEmail)
        
        /* Getting the existing favorite profiles */
        docRef.getDocument { (document, error) in
            if let document = document, document.exists {
                
                /* Removing from array */
                if var favProfiles = document.data()!["profiles"] as? [String] {
                    if let indexToRemove = favProfiles.firstIndex(of: self.partnerEmail) {
                        favProfiles.remove(at: indexToRemove)
                        
                        /* Updating the array of profiles */
                        docRef.updateData(["profiles": favProfiles]) { error in
                            if let e = error {
                                print(e.localizedDescription)
                            }
                        }
                    }
                }
            }
        }
        
        /* Getting the collection */
        let partnerRef = UtilityConstants.db.collection("Users").document(self.partnerEmail)
        
        /* Getting the profile of the partner */
        partnerRef.getDocument { (document, error) in
            if let document = document, document.exists {
                
                /* Reducing the likes count */
                if let likesCount = document.data()!["likes"] as? Int {
                    
                    /* Updating the likes count of profiles */
                    partnerRef.updateData(["likes": likesCount - 1]) { error in
                        if let e = error {
                            print(e.localizedDescription)
                        }
                    }
                }
                
                /* Removing partner profile */
                if var likedBy = document.data()!["likedBy"] as? [String] {
                    if let indexToRemove = likedBy.firstIndex(of: email) {
                        likedBy.remove(at: indexToRemove)
                        
                        /* Updating the likedBy array */
                        partnerRef.updateData(["likedBy": likedBy]) { error in
                            if let e = error {
                                print(e.localizedDescription)
                            }
                        }
                    }
                }
            }
        }
    }
}
