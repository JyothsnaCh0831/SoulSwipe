//
//  ViewController.swift
//  SoulSwipeProject
//
//  Created by Jyothsna on 10/17/23.
//

import UIKit
import Lottie

class LaunchScreen: UIViewController {

    override func viewDidLoad() {
        
        // Playing the animation
        self.logo.animation = LottieAnimation.named("go")
        self.logo.loopMode = .playOnce
        self.logo.play {
            [weak self] _ in
            
            /* Checking whether user is logged in or not */
            if (UserDefaults.standard.bool(forKey: "isLoggedIn") == true) {
                let home = self?.storyboard?.instantiateViewController(withIdentifier: "userTabBar")as! UserTabBar
                self?.navigationController?.pushViewController(home, animated: true)
            } else {
                self?.logo.isHidden = true
            }
        }
        super.viewDidLoad()
       

    }
    
    
    @IBOutlet weak var logo: LottieAnimationView!
    
    @IBAction func onClickLogin(_ sender: UIButton) {
        /* Navigating to SignIn Screen */
        self.performSegue(withIdentifier: "showLoginScreen", sender: self)
    }
    
    @IBAction func onClickRegister(_ sender: UIButton) {
        /* Navigating to SignUp Screen */
        self.performSegue(withIdentifier: "showSignupScreen", sender: self)
    }
}

