//
//  BlockedProfilesVCViewController.swift
//  SoulSwipeProject
//
//  Created by Jyothsna on 10/23/23.
//

import UIKit
import FirebaseAuth

class LikesVC: UIViewController, UITableViewDelegate, UITableViewDataSource {
    
    var likedByProfiles: [[String: Any]] = []

    @IBOutlet weak var likesTV: UITableView!
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        /* Display the nav bar */
        self.navigationController?.navigationBar.isHidden = false

        /* Customize the back button text for this view controller */
        let backButton = UIBarButtonItem()
        backButton.tintColor = UIColor.systemRed
        self.navigationController?.navigationBar.topItem?.backBarButtonItem = backButton
        
        /* Answering the delegate */
        self.likesTV.dataSource = self
        self.likesTV.delegate = self
        
        /* Styling the table view */
        self.likesTV.separatorStyle = .none
        
        /* Calling method to read profiles */
        self.getAllProfiles { profiles in
            self.likedByProfiles = profiles
            self.likesTV.reloadData()
        }
    }
    
    /* Overriding the table view methods */
    func numberOfSections(in tableView: UITableView) -> Int {
        return self.likedByProfiles.count
    }
    
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return 1
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let cell = self.likesTV.dequeueReusableCell(withIdentifier: "likesFromProfiles", for: indexPath) as! LikesCell
        
        /* Apply the corner radius and mask to bounds to round the cell */
        cell.layer.cornerRadius = 12.0
        cell.layer.masksToBounds = true

        /* Set the background color of the cell */
        cell.contentView.backgroundColor = UIColor.white
        
        let profile = self.likedByProfiles[indexPath.section]
        
        cell.partnerName.text = profile["fullName"] as? String
        cell.partnerProfession.text = profile["profession"] as? String
        
        /* Image */
        if let data = UserDefaults.standard.data(forKey: profile["email"] as! String) {
            let decoded = try! PropertyListDecoder().decode(Data.self, from: data)
            cell.profileIMG.image = UIImage(data: decoded)
        }
        cell.profileIMG.layer.cornerRadius = 10.0
        cell.profileIMG.layer.masksToBounds = true
        
        return cell
    }
    
    func tableView(_ tableView: UITableView, heightForRowAt indexPath: IndexPath) -> CGFloat {
        return 75
    }
    
    /* Spacing between the cells */
    func tableView(_ tableView: UITableView, heightForHeaderInSection section: Int) -> CGFloat {
        return 1.0
    }
    
    func tableView(_ tableView: UITableView, viewForHeaderInSection section: Int) -> UIView? {
        let headerView = UIView()
        headerView.backgroundColor = UIColor.clear
        return headerView
    }
}

extension LikesVC {
    /* Retrieve the profiles who liked */
    func getAllProfiles(completion: @escaping ([[String: Any]]) -> Void) {
        
        /* Current user email */
        guard let user = Auth.auth().currentUser, let email = user.email else {
            return
        }
        
        var profilesDetails: [[String: Any]] = []
        
        let usersRef = UtilityConstants.db.collection("Users").document(email)
        usersRef.getDocument { (document, error) in
            if let e = error {
                print(e.localizedDescription)
            }
            
            if let document = document, document.exists {
                if let data = document.data()!["likedBy"] as? [String] {
                    for partnerMail in data {
                        UtilityConstants.db.collection("Users").document(partnerMail).getDocument { (document, error) in
                            if let e = error {
                                print(e.localizedDescription)
                            }
                        
                            if let document = document, document.exists {
                                if let data = document.data() {
                                    profilesDetails.append(data)
                                    print(profilesDetails)
                                }
                            }
                            completion(profilesDetails)
                        }
                    }
                }
            }
        }
    }
}
