//
//  BlockedProfileCell.swift
//  SoulSwipeProject
//
//  Created by Jyothsna on 10/23/23.
//

import UIKit

class LikesCell: UITableViewCell {
    
    @IBOutlet weak var profileIMG: UIImageView!
    
    @IBOutlet weak var partnerName: UILabel!
    
    @IBOutlet weak var partnerProfession: UILabel!
    
    override func awakeFromNib() {
        super.awakeFromNib()
    }

    override func setSelected(_ selected: Bool, animated: Bool) {
        super.setSelected(selected, animated: animated)

    }
}
