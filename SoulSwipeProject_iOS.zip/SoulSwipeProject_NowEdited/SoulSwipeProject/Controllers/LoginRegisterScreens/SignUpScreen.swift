//
//  SignUpScreen.swift
//  SoulSwipeProject
//
//  Created by Jyothsna on 10/17/23.
//

import UIKit
import FirebaseAuth
import FirebaseFirestore
import CometChatUIKitSwift
import CometChatSDK

class SignUpScreen: UIViewController, UITextFieldDelegate {
    
    @IBOutlet weak var emailTF: UITextField!
    
    @IBOutlet weak var firstNameTF: UITextField!
    
    @IBOutlet weak var lastNameTF: UITextField!
    
    @IBOutlet weak var datePicker: UIDatePicker!
    
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        /* Answering the TextField delegate */
        self.emailTF.delegate = self
        self.firstNameTF.delegate = self
        self.lastNameTF.delegate = self
        
        /* Customize the back button text for this view controller */
        let backButton = UIBarButtonItem()
        backButton.tintColor = UIColor.systemRed
        self.navigationController?.navigationBar.topItem?.backBarButtonItem = backButton
        
        /* Rounding the corners of text fields */
        self.applyRoundedCorners(for: self.emailTF)
        self.applyRoundedCorners(for: self.firstNameTF)
        self.applyRoundedCorners(for: self.lastNameTF)
        
        /* Round corners for date picker */
        self.datePicker.layer.cornerRadius = 12.0
        self.datePicker.layer.masksToBounds = true
        self.datePicker.tintColor = UIColor.systemPurple
        
    }
    
    
    @IBAction func onClickRegister(_ sender: UIButton) {
        
        /* Get the e-mail address */
        guard let email = self.emailTF.text, !email.isEmpty else {
            UtilityConstants.displayAlert(for: self, having: "Error", with: "E-mail address cannot be empty. Please try again.", and: UtilityConstants.defaultAction)
            return
        }
        
        /* Get the first name */
        guard let fname = self.firstNameTF.text, !fname.isEmpty else {
            UtilityConstants.displayAlert(for: self, having: "Error", with: "Firstname cannot be empty. Please try again.", and: UtilityConstants.defaultAction)
            return
        }
        
        /* Get the last name */
        guard let lname = self.lastNameTF.text, !lname.isEmpty else {
            UtilityConstants.displayAlert(for: self, having: "Error", with: "Lastname cannot be empty. Please try again.", and: UtilityConstants.defaultAction)
            return
        }
        
        /* Get the birthday */
        let selectedDate = datePicker.date
        let dateFormatter = DateFormatter()
        dateFormatter.dateFormat = "yyyy/MM/dd"
        let formattedDate = dateFormatter.string(from: selectedDate)
        
        let calendar = Calendar.current
        let now = Date()
        
        /* Checking the age of the user */
        let ageComponents = calendar.dateComponents([.year], from: selectedDate, to: now)
        guard let age = ageComponents.year else {
            return
        }
        
        /* User cannot be 18 years below */
        if(age < 18) {
            UtilityConstants.displayAlert(for: self, having: "Info", with: "We apologize but you are under-age to use register for this application", and: UtilityConstants.defaultAction)
            return
        }
        
        /* Checking the e-mail */
        if self.hasCorrectDomain(email: email) {
            Auth.auth().createUser(withEmail: email, password: "dummypswdnwmsu@!123") { firebaserslt, err in
                
                /* Already account exists */
                if let _ = err{
                    let action = UIAlertAction(title: "OK", style: .default) { (action) in
                        let login = self.storyboard?.instantiateViewController(withIdentifier: "loginScreen") as! LoginScreen
                        self.navigationController?.pushViewController(login, animated: true)
                    }
                    UtilityConstants.displayAlert(for: self, having: "Info", with: "An account already exists with this e-mail address", and: action)
                } else {
                    
                    /* Setting the user default initially to false */
                    UserDefaults.standard.set(false, forKey: "isLoggedIn")
                    
                    /* If already data exists */
                    UtilityConstants.db.collection("Users").whereField("e-mail", isEqualTo: email).getDocuments { (snapshot, error) in
                        if let error = error {
                            print("Error getting documents: \(error)")
                            return
                        }
                        if let snapshot = snapshot {
                            if !snapshot.isEmpty {
                                for document in snapshot.documents {
                                    let documentData = document.data()
                                    print(documentData)
                                }
                                
                            } else {
                                
                                UtilityConstants.db.collection("Users").document(email).getDocument { (document, error) in
                                    
                                    /* If data already exists - Not new user */
                                    if let document = document, document.exists {
                                        if let data = document.data() {
                                            
                                            /* Reactivating the account */
                                            if (data["isAccountDeleted"] as! Bool == true) {
                                                UtilityConstants.displayAlert(for: self, having: "🎉 Welcome back! 🎉", with: "We're thrilled to see you return to our community! Your account has been successfully reactivated, and we're here to continue the journey with you.", and: UtilityConstants.defaultAction)
                                                /* Navigating to SignIn Screen */
                                                let login = self.storyboard?.instantiateViewController(withIdentifier: "loginScreen")as! LoginScreen
                                                self.navigationController?.pushViewController(login, animated: true)
                                            }
                                            
                                            UtilityConstants.db.collection("Users").document(email)
                                                .updateData(
                                                    [
                                                        "isAccountDeleted": false
                                                    ]
                                                ) { error in
                                                    if let e = error {
                                                        print(e.localizedDescription)
                                                    }
                                                }
                                        }
                                    } else {
                                        let cometChatID = self.registerUsertoCometChat(for: fname, for: lname)
                                        
                                        /* Setting the data to firestore */
                                        UtilityConstants.db.collection("Users").document(email).setData([
                                            "firstName": fname,
                                            "lastName": lname,
                                            "fullName": (fname + " " + lname),
                                            "email": email,
                                            "birthday": formattedDate,
                                            "profession": String(),
                                            "isAccountDeleted": false,
                                            "isAccountBlocked": false,
                                            "likes": 0,
                                            "likedBy": [],
                                            "reports": 0,
                                            "aboutMe": String(),
                                            "gender": String(),
                                            "partnerGender": String(),
                                            "age": age,
                                            "cometchatID" : cometChatID
                                        ])
                                        
                                        self.updateUniqueID()
                                    }
                                }
                                
                                /* Clearing the text fields */
                                self.lastNameTF.text = ""
                                self.firstNameTF.text = ""
                                self.emailTF.text = ""
                            }
                        }
                    }
                    
                    /* Sending mail to reset password */
                    Auth.auth().sendPasswordReset(withEmail: email){error in
                        if let _ = error{
                            UtilityConstants.displayAlert(for: self, having: "Error", with: "Error occurred while storing details into database", and: UtilityConstants.defaultAction)
                        } else {
                            let action = UIAlertAction(title: "OK", style: .default) { (action) in
                                let login = self.storyboard?.instantiateViewController(withIdentifier: "loginScreen")as! LoginScreen
                                self.navigationController?.pushViewController(login, animated: true)
                            }
                            UtilityConstants.displayAlert(for: self, having: "Success", with: "You are sucessfully registered. A password link has been sent to your e-mail address for setting your password", and: action)
                        }
                    }
                }
            }
        } else {
            /* if e-mail address is not a gmail one*/
            UtilityConstants.displayAlert(for: self, having: "Info", with: "Email does not have the correct domain. Please try with registered email id.", and: UtilityConstants.defaultAction)
            self.emailTF.text = ""
        }
    }
    
    
    @IBAction func onClickLogin(_ sender: UIButton) {
        /* Navigating to SignIn Screen */
        let login = self.storyboard?.instantiateViewController(withIdentifier: "loginScreen")as! LoginScreen
        self.navigationController?.pushViewController(login, animated: true)
    }
    
    
    /* Change color to red when started editing */
    func textFieldDidBeginEditing(_ sender: UITextField) {
        sender.layer.borderWidth = 1.0
        sender.layer.borderColor = UIColor.systemRed.cgColor
    }
    
    /* Change color to gray when done editing */
    func textFieldDidEndEditing(_ sender: UITextField) {
        sender.layer.borderWidth = 1.0
        sender.layer.borderColor = UIColor.systemGray.cgColor
    }
    
    /* Applying style for the text fields */
    private func applyRoundedCorners(for sender: UITextField) {
        sender.layer.cornerRadius = 25.0
        sender.layer.masksToBounds = true
        sender.layer.borderColor = UIColor.systemGray.cgColor
        sender.layer.borderWidth = 1.0
    }
    
    /* Checking the e-mail domain */
    private func hasCorrectDomain(email: String) -> Bool {
        let emailDomain = "@gmail.com"
        return email.hasSuffix(emailDomain)
    }
    
    /* Register user to cometchat*/
    private func registerUsertoCometChat(for fname: String, for lname: String ) -> String{
        
        let uniqueId = getUniqueID() + 1
        let name = (fname + " " + lname)
        var uid = fname.lowercased() + lname.lowercased() + String(uniqueId)
        let user = User(uid: uid, name: name)
        
        CometChatUIKit.create(user: user) { result in
            switch result {
            case .success(_):
                debugPrint("User created successfully \(user.name!)")
                break
            case .onError(let error):
                debugPrint("Creating new user failed with exception: \(error.errorDescription)")
                uid = ""
                break
            }
        }
        return uid
    }
    
    private func getUniqueID() -> Int{
        var val = 0
        UtilityConstants.db.collection("UniqueID").document("id").getDocument { (document, error) in
            if let error = error {
                print("Error getting document: \(error)")
            } else if let document = document, document.exists {
                if let data = document.data(){
                    val = data["value"] as! Int
                    //print("Document data: \(data )")
                    //print(val)
                }
            } else {
                print("Document does not exist")
            }
        }
        return val
    }
    
    private func updateUniqueID(){
        let val = getUniqueID()
        let updatedData: [String: Any] = [
            "value": val + 1
        ]
        UtilityConstants.db.collection("UniqueID").document("id").setData(updatedData, merge: true) { error in
            if let error = error {
                print("Error updating document: \(error)")
            } else {
                print("Document successfully updated")
            }
        }
    }
}
