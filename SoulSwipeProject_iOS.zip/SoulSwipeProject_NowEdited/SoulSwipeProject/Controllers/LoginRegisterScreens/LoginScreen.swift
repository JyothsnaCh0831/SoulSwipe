//
//  LoginScreen.swift
//  SoulSwipeProject
//
//  Created by Jyothsna on 10/17/23.
//

import UIKit
import FirebaseAuth
import FirebaseFirestore
import CometChatUIKitSwift
import CometChatSDK

class LoginScreen: UIViewController, UITextFieldDelegate {
    
    @IBOutlet weak var emailTF: UITextField!
    
    @IBOutlet weak var passwordTF: UITextField!
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        /* Answering the TextField delegate */
        self.emailTF.delegate = self
        self.passwordTF.delegate = self
        
        /* Customize the back button text for this view controller */
        let backButton = UIBarButtonItem()
        backButton.tintColor = UIColor.systemRed
        self.navigationController?.navigationBar.topItem?.backBarButtonItem = backButton
        
        /* Rounding the corners of text fields */
        self.applyRoundedCorners(for: self.emailTF)
        self.applyRoundedCorners(for: self.passwordTF)
    }
    
    
    @IBAction func onClickLogin(_ sender: UIButton) {
        
        /* Get the e-mail address */
        guard let email = self.emailTF.text, !email.isEmpty else {
            UtilityConstants.displayAlert(for: self, having: "Error", with: "E-mail address cannot be empty. Please try again.", and: UtilityConstants.defaultAction)
            return
        }
        
        /* Get the password */
        guard let password = self.passwordTF.text, !password.isEmpty else {
            UtilityConstants.displayAlert(for: self, having: "Error", with: "Password cannot be empty. Please try again.", and: UtilityConstants.defaultAction)
            return
        }
        
        /* Signing the user */
        Auth.auth().signIn(withEmail: email, password: password) { firebaseResult, error in
            
            /* Wrong Credentials */
            if let _ = error {
                UtilityConstants.displayAlert(for: self, having: "Error", with: "Invalid Credentials. Please try again.", and: UtilityConstants.defaultAction)
            } else {
                
                /* Setting the User Default to true */
                UserDefaults.standard.set(true, forKey: "isLoggedIn")
                
                /* Checking if account exists or not */
                UtilityConstants.db.collection("Users").document(email).getDocument { (document, error) in
                    if let document = document, document.exists {
                        
                        if let data = document.data() {
                            
                            /* Check if account is deleted or not */
                            if let isAccountDeleted = data["isAccountDeleted"] as? Bool, isAccountDeleted == true {
                                
                                /* Display alert */
                                UtilityConstants.displayAlert(for: self, having: "Account Deleted", with: "We regret to inform you that your account has been deleted. As a result, you can no longer log in with the provided credentials", and: UtilityConstants.defaultAction)
                                
                                self.emailTF.text = ""
                                self.passwordTF.text = ""
                                
                            } else {
                                
                                /* Checking if the questionnaire is already given or not */
                                UtilityConstants.db.collection("CompatibilityQuiz").document(email).getDocument { (document, error) in
                                    
                                    /* If questionnaire is done */
                                    if let document = document, document.exists {
                                        /* Navigate to home screen */
                                        self.performSegue(withIdentifier: "showUserTabBar", sender: self)
                                    } else {
                                        /* Take the questionnaire */
                                        self.performSegue(withIdentifier: "showGenderSelectionScreen", sender: self)
                                    }
                                }
                                
                                // Login user to cometchat
                                self.getCometChatUserID(email: email) { id in
                                    self.loginUser(uid: id)
                                }
                            }
                        }
                        
                    } else {
                        /* Account not exists */
                        UtilityConstants.displayAlert(for: self, having: "Error", with: "Apologies. No account with the registered account", and: UtilityConstants.defaultAction)
                    }
                }
            }
        }
    }
    
    @IBAction func onClickRegister(_ sender: UIButton) {
        /* Navigating to SignUp Screen */
        let register = self.storyboard?.instantiateViewController(withIdentifier: "signupScreen")as! SignUpScreen
        self.navigationController?.pushViewController(register, animated: true)
    }
    
    
    /* Change color to red when started editing */
    func textFieldDidBeginEditing(_ sender: UITextField) {
        sender.layer.borderWidth = 1.0
        sender.layer.borderColor = UIColor.systemRed.cgColor
    }
    
    /* Change color to gray when done editing */
    func textFieldDidEndEditing(_ sender: UITextField) {
        sender.layer.borderWidth = 1.0
        sender.layer.borderColor = UIColor.systemGray.cgColor
    }
    
    /* Applying style for the text fields */
    private func applyRoundedCorners(for sender: UITextField) {
        sender.layer.cornerRadius = 25.0
        sender.layer.masksToBounds = true
        sender.layer.borderColor = UIColor.systemGray.cgColor
        sender.layer.borderWidth = 1.0
    }
    
    //Get user details from User collection
    private func getCometChatUserID(email: String, completion: @escaping (String) -> Void){
        var cometChatID = ""
        UtilityConstants.db.collection("Users").document(email).getDocument { (document, error) in
            if let error = error {
                print("Error getting document: \(error)")
            } else if let document = document, document.exists {
                if let data = document.data(){
                    cometChatID = data["cometchatID"] as! String
                    completion(cometChatID)
                }
            } else {
                print("Document does not exist")
            }
        }
    }
    
    // Login to CometChat
    private func loginUser(uid: String) {
        CometChatUIKit.login(uid: uid) { result in
            switch result {
            case .success(let user):
                debugPrint("User logged in successfully  \(user.name!)")
                break
            case .onError(let error):
                debugPrint("Login failed with exception: \(error.errorDescription)")
                break
            }
        }
    }
}
