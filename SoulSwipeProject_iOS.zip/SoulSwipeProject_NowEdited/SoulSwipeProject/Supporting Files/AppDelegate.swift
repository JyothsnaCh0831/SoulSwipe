//
//  AppDelegate.swift
//  SoulSwipeProject
//
//  Created by Jyothsna on 10/17/23.
//

import UIKit
import FirebaseCore
import CometChatUIKitSwift

@main
class AppDelegate: UIResponder, UIApplicationDelegate {
    
    func application(_ application: UIApplication, didFinishLaunchingWithOptions launchOptions: [UIApplication.LaunchOptionsKey: Any]?) -> Bool {
        // Override point for customization after application launch.
        FirebaseApp.configure()
        
        //Initialize cometchat
        let uikitSettings = UIKitSettings()
        uikitSettings.set(appID:  "248046a2c0a8c1fa" )
            .set(authKey: "38ee79f686db20ddf6e86765691bd510ca4c0a28")
            .set(region: "us" )
            .subscribePresenceForAllUsers()
            .build()
        CometChatUIKit.init(uiKitSettings: uikitSettings, result: { result in
            switch result {
            case .success(let success):
                debugPrint("Initialization completed successfully \(success)")
                break
            case .failure(let error):
                debugPrint( "Initialization failed with exception: \(error.localizedDescription)")
                break
            }
        })
        
        // Creating Palette
        let palette = Palette()
        palette.set(background: .systemGray6)
        palette.set(primary: .systemRed)
        //palette.set(accent: .systemPurple)
        
        // Creating Typography
        var typography = Typography()
        typography.setFont(heading: UIFont(name: "Noteworthy-Bold", size: 35)!)
        typography.setFont(name: UIFont(name: "Futura-Medium", size: 15)!)
        typography.setFont(caption1: UIFont(name: "Futura-Medium", size: 13)!)
        
        // If the user wants to override the whole font family
        let fontFamily = CometChatFontFamily(regular: "Futura", medium: "Futura-Medium", bold: "Futura-Bold")
        typography.overrideFont(family: fontFamily)
        
        // Initializing Theme
        CometChatTheme.init(typography: typography, palatte: palette)
        
        return true
    }
    
    // MARK: UISceneSession Lifecycle
    
    func application(_ application: UIApplication, configurationForConnecting connectingSceneSession: UISceneSession, options: UIScene.ConnectionOptions) -> UISceneConfiguration {
        // Called when a new scene session is being created.
        // Use this method to select a configuration to create the new scene with.
        return UISceneConfiguration(name: "Default Configuration", sessionRole: connectingSceneSession.role)
    }
    
    func application(_ application: UIApplication, didDiscardSceneSessions sceneSessions: Set<UISceneSession>) {
        // Called when the user discards a scene session.
        // If any sessions were discarded while the application was not running, this will be called shortly after application:didFinishLaunchingWithOptions.
        // Use this method to release any resources that were specific to the discarded scenes, as they will not return.
    }
}

